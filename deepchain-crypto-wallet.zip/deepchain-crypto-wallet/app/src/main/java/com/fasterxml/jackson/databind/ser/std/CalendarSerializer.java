package com.fasterxml.jackson.databind.ser.std;

import java.util.Calendar;

/* loaded from: classes.dex */
public final class CalendarSerializer extends DateTimeSerializerBase<Calendar> {
    public static final CalendarSerializer instance = new CalendarSerializer();

    public CalendarSerializer() {
        this((byte) 0);
    }

    private CalendarSerializer(byte b) {
        super(Calendar.class, null);
    }
}
