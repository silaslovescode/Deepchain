package com.fasterxml.jackson.databind.ser.std;

/* loaded from: classes.dex */
public final class StringSerializer extends NonTypedScalarSerializerBase<Object> {
    private static final long serialVersionUID = 1;

    public StringSerializer() {
        super(String.class, (byte) 0);
    }
}
