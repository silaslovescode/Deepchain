package com.fasterxml.jackson.databind.ser.std;

import java.io.File;

/* loaded from: classes.dex */
public class FileSerializer extends StdScalarSerializer<File> {
    public FileSerializer() {
        super(File.class);
    }
}
