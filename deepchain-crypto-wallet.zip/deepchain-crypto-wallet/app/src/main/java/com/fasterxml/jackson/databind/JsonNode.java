package com.fasterxml.jackson.databind;

import com.fasterxml.jackson.databind.JsonSerializable;

/* loaded from: classes.dex */
public abstract class JsonNode extends JsonSerializable.Base implements Iterable<JsonNode> {
    protected JsonNode() {
    }
}
