package com.fasterxml.jackson.core.p003io;

import java.io.Serializable;

/* renamed from: com.fasterxml.jackson.core.io.InputDecorator */
/* loaded from: classes.dex */
public abstract class InputDecorator implements Serializable {
    private static final long serialVersionUID = 1;
}
