package com.fasterxml.jackson.databind.deser;

/* loaded from: classes.dex */
public interface Deserializers {
}
