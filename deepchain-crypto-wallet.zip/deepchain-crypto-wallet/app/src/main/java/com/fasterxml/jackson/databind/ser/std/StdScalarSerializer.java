package com.fasterxml.jackson.databind.ser.std;

/* loaded from: classes.dex */
public abstract class StdScalarSerializer<T> extends StdSerializer<T> {
    /* JADX INFO: Access modifiers changed from: protected */
    public StdScalarSerializer(Class<T> t) {
        super(t);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public StdScalarSerializer(Class<?> t, byte b) {
        super(t);
    }
}
