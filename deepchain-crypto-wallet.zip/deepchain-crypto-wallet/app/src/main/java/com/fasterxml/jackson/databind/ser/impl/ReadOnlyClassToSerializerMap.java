package com.fasterxml.jackson.databind.ser.impl;

/* loaded from: classes.dex */
public final class ReadOnlyClassToSerializerMap {
}
