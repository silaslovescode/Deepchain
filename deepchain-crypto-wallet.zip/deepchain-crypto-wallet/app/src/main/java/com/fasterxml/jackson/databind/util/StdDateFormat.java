package com.fasterxml.jackson.databind.util;

import com.fasterxml.jackson.core.p003io.NumberInput;
import java.text.DateFormat;
import java.text.FieldPosition;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/* loaded from: classes.dex */
public final class StdDateFormat extends DateFormat {
    protected static final DateFormat DATE_FORMAT_ISO8601;
    protected static final DateFormat DATE_FORMAT_ISO8601_Z;
    protected static final DateFormat DATE_FORMAT_PLAIN;
    protected static final DateFormat DATE_FORMAT_RFC1123;
    public static final StdDateFormat instance;
    protected transient DateFormat _formatISO8601;
    protected transient DateFormat _formatISO8601_z;
    protected transient DateFormat _formatPlain;
    protected transient DateFormat _formatRFC1123;
    protected Boolean _lenient;
    protected final Locale _locale;
    protected transient TimeZone _timezone;
    protected static final String[] ALL_FORMATS = {"yyyy-MM-dd'T'HH:mm:ss.SSSZ", "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", "EEE, dd MMM yyyy HH:mm:ss zzz", "yyyy-MM-dd"};
    private static final TimeZone DEFAULT_TIMEZONE = TimeZone.getTimeZone("UTC");
    private static final Locale DEFAULT_LOCALE = Locale.US;

    static {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", DEFAULT_LOCALE);
        DATE_FORMAT_RFC1123 = simpleDateFormat;
        simpleDateFormat.setTimeZone(DEFAULT_TIMEZONE);
        SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", DEFAULT_LOCALE);
        DATE_FORMAT_ISO8601 = simpleDateFormat2;
        simpleDateFormat2.setTimeZone(DEFAULT_TIMEZONE);
        SimpleDateFormat simpleDateFormat3 = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", DEFAULT_LOCALE);
        DATE_FORMAT_ISO8601_Z = simpleDateFormat3;
        simpleDateFormat3.setTimeZone(DEFAULT_TIMEZONE);
        SimpleDateFormat simpleDateFormat4 = new SimpleDateFormat("yyyy-MM-dd", DEFAULT_LOCALE);
        DATE_FORMAT_PLAIN = simpleDateFormat4;
        simpleDateFormat4.setTimeZone(DEFAULT_TIMEZONE);
        instance = new StdDateFormat();
    }

    public StdDateFormat() {
        this._locale = DEFAULT_LOCALE;
    }

    private StdDateFormat(TimeZone tz, Locale loc, Boolean lenient) {
        this._timezone = tz;
        this._locale = loc;
        this._lenient = lenient;
    }

    @Override // java.text.DateFormat
    public final TimeZone getTimeZone() {
        return this._timezone;
    }

    @Override // java.text.DateFormat
    public final void setTimeZone(TimeZone tz) {
        if (!tz.equals(this._timezone)) {
            _clearFormats();
            this._timezone = tz;
        }
    }

    @Override // java.text.DateFormat
    public final void setLenient(boolean enabled) {
        Boolean newValue = Boolean.valueOf(enabled);
        if (this._lenient != newValue) {
            this._lenient = newValue;
            _clearFormats();
        }
    }

    @Override // java.text.DateFormat
    public final boolean isLenient() {
        if (this._lenient == null) {
            return true;
        }
        return this._lenient.booleanValue();
    }

    @Override // java.text.DateFormat
    public final Date parse(String dateStr) throws ParseException {
        Date dt;
        String dateStr2 = dateStr.trim();
        ParsePosition pos = new ParsePosition(0);
        if (looksLikeISO8601(dateStr2)) {
            dt = parseAsISO8601$12fed862(dateStr2, pos);
        } else {
            int i = dateStr2.length();
            while (true) {
                i--;
                if (i < 0) {
                    break;
                }
                char ch = dateStr2.charAt(i);
                if (ch < '0' || ch > '9') {
                    if (i > 0 || ch != '-') {
                        break;
                    }
                }
            }
            if (i < 0 && (dateStr2.charAt(0) == '-' || NumberInput.inLongRange$505cbf47(dateStr2))) {
                dt = new Date(Long.parseLong(dateStr2));
            } else {
                dt = parseAsRFC1123(dateStr2, pos);
            }
        }
        if (dt != null) {
            return dt;
        }
        StringBuilder sb = new StringBuilder();
        String[] arr$ = ALL_FORMATS;
        for (String f : arr$) {
            if (sb.length() > 0) {
                sb.append("\", \"");
            } else {
                sb.append('\"');
            }
            sb.append(f);
        }
        sb.append('\"');
        throw new ParseException(String.format("Can not parse date \"%s\": not compatible with any of standard forms (%s)", dateStr2, sb.toString()), pos.getErrorIndex());
    }

    @Override // java.text.DateFormat
    public final Date parse(String dateStr, ParsePosition pos) {
        if (looksLikeISO8601(dateStr)) {
            try {
                return parseAsISO8601$12fed862(dateStr, pos);
            } catch (ParseException e) {
                return null;
            }
        }
        int i = dateStr.length();
        while (true) {
            i--;
            if (i < 0) {
                break;
            }
            char ch = dateStr.charAt(i);
            if (ch < '0' || ch > '9') {
                if (i > 0 || ch != '-') {
                    break;
                }
            }
        }
        if (i < 0 && (dateStr.charAt(0) == '-' || NumberInput.inLongRange$505cbf47(dateStr))) {
            return new Date(Long.parseLong(dateStr));
        }
        return parseAsRFC1123(dateStr, pos);
    }

    @Override // java.text.DateFormat
    public final StringBuffer format(Date date, StringBuffer toAppendTo, FieldPosition fieldPosition) {
        if (this._formatISO8601 == null) {
            this._formatISO8601 = _cloneFormat(DATE_FORMAT_ISO8601, "yyyy-MM-dd'T'HH:mm:ss.SSSZ", this._timezone, this._locale, this._lenient);
        }
        return this._formatISO8601.format(date, toAppendTo, fieldPosition);
    }

    public final String toString() {
        String str = "DateFormat " + getClass().getName();
        TimeZone tz = this._timezone;
        if (tz != null) {
            str = str + " (timezone: " + tz + ")";
        }
        return str + "(locale: " + this._locale + ")";
    }

    @Override // java.text.DateFormat
    public final boolean equals(Object o) {
        return o == this;
    }

    @Override // java.text.DateFormat
    public final int hashCode() {
        return System.identityHashCode(this);
    }

    private static boolean looksLikeISO8601(String dateStr) {
        return dateStr.length() >= 5 && Character.isDigit(dateStr.charAt(0)) && Character.isDigit(dateStr.charAt(3)) && dateStr.charAt(4) == '-';
    }

    /* JADX WARN: Removed duplicated region for block: B:29:0x0097  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x014a  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private java.util.Date parseAsISO8601$12fed862(java.lang.String r14, java.text.ParsePosition r15) throws java.text.ParseException {
        /*
            Method dump skipped, instructions count: 434
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.fasterxml.jackson.databind.util.StdDateFormat.parseAsISO8601$12fed862(java.lang.String, java.text.ParsePosition):java.util.Date");
    }

    private Date parseAsRFC1123(String dateStr, ParsePosition pos) {
        if (this._formatRFC1123 == null) {
            this._formatRFC1123 = _cloneFormat(DATE_FORMAT_RFC1123, "EEE, dd MMM yyyy HH:mm:ss zzz", this._timezone, this._locale, this._lenient);
        }
        return this._formatRFC1123.parse(dateStr, pos);
    }

    private static final DateFormat _cloneFormat(DateFormat df, String format, TimeZone tz, Locale loc, Boolean lenient) {
        DateFormat df2;
        if (!loc.equals(DEFAULT_LOCALE)) {
            df2 = new SimpleDateFormat(format, loc);
            if (tz == null) {
                tz = DEFAULT_TIMEZONE;
            }
            df2.setTimeZone(tz);
        } else {
            df2 = (DateFormat) df.clone();
            if (tz != null) {
                df2.setTimeZone(tz);
            }
        }
        if (lenient != null) {
            df2.setLenient(lenient.booleanValue());
        }
        return df2;
    }

    private void _clearFormats() {
        this._formatRFC1123 = null;
        this._formatISO8601 = null;
        this._formatISO8601_z = null;
        this._formatPlain = null;
    }

    @Override // java.text.DateFormat, java.text.Format
    public final /* bridge */ /* synthetic */ Object clone() {
        return new StdDateFormat(this._timezone, this._locale, this._lenient);
    }
}
