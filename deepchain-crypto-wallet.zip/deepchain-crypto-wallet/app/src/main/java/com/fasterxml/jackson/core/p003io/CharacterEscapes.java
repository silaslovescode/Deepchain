package com.fasterxml.jackson.core.p003io;

import java.io.Serializable;

/* renamed from: com.fasterxml.jackson.core.io.CharacterEscapes */
/* loaded from: classes.dex */
public abstract class CharacterEscapes implements Serializable {
}
