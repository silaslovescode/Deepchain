package com.fasterxml.jackson.databind.util;

/* loaded from: classes.dex */
public final class LinkedNode<T> {
}
