package com.fasterxml.jackson.databind.type;

import java.io.Serializable;

/* loaded from: classes.dex */
public final class ClassKey implements Serializable, Comparable<ClassKey> {
    private static final long serialVersionUID = 1;
    private Class<?> _class;
    private String _className;
    private int _hashCode;

    @Override // java.lang.Comparable
    public final /* bridge */ /* synthetic */ int compareTo(ClassKey classKey) {
        return this._className.compareTo(classKey._className);
    }

    public ClassKey() {
        this._class = null;
        this._className = null;
        this._hashCode = 0;
    }

    public ClassKey(Class<?> clz) {
        this._class = clz;
        this._className = clz.getName();
        this._hashCode = this._className.hashCode();
    }

    public final boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        return o != null && o.getClass() == getClass() && ((ClassKey) o)._class == this._class;
    }

    public final int hashCode() {
        return this._hashCode;
    }

    public final String toString() {
        return this._className;
    }
}
