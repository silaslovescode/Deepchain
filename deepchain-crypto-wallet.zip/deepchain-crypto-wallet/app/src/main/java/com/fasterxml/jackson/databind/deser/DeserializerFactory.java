package com.fasterxml.jackson.databind.deser;

/* loaded from: classes.dex */
public abstract class DeserializerFactory {
    protected static final Deserializers[] NO_DESERIALIZERS = new Deserializers[0];
}
