package com.fasterxml.jackson.databind.deser;

import com.fasterxml.jackson.databind.JavaType;
import java.io.Serializable;
import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;

/* loaded from: classes.dex */
public final class DeserializerCache implements Serializable {
    private static final long serialVersionUID = 1;
    protected final ConcurrentHashMap<JavaType, Object<Object>> _cachedDeserializers = new ConcurrentHashMap<>(64, 0.75f, 4);
    protected final HashMap<JavaType, Object<Object>> _incompleteDeserializers = new HashMap<>(8);

    final Object writeReplace() {
        this._incompleteDeserializers.clear();
        return this;
    }
}
