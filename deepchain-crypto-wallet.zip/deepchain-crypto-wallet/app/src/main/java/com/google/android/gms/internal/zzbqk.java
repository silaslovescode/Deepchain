package com.google.android.gms.internal;

import java.util.concurrent.atomic.AtomicReference;

/* loaded from: classes.dex */
public final class zzbqk {
    private static final AtomicReference<zzbqk> zzbUK = new AtomicReference<>();

    zzbqk() {
    }

    public static void zzg$4c05e04e() {
    }
}
