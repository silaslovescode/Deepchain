package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.zzb;

/* loaded from: classes.dex */
public final class zzo implements Parcelable.Creator<Tile> {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static void zza$2bae1718(Tile tile, Parcel parcel) {
        int zzH = com.google.android.gms.common.internal.safeparcel.zzc.zzH(parcel, 20293);
        com.google.android.gms.common.internal.safeparcel.zzc.zzc(parcel, 1, tile.mVersionCode);
        com.google.android.gms.common.internal.safeparcel.zzc.zzc(parcel, 2, tile.width);
        com.google.android.gms.common.internal.safeparcel.zzc.zzc(parcel, 3, tile.height);
        byte[] bArr = tile.data;
        if (bArr != null) {
            int zzH2 = com.google.android.gms.common.internal.safeparcel.zzc.zzH(parcel, 4);
            parcel.writeByteArray(bArr);
            com.google.android.gms.common.internal.safeparcel.zzc.zzI(parcel, zzH2);
        }
        com.google.android.gms.common.internal.safeparcel.zzc.zzI(parcel, zzH);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Tile[] newArray(int i) {
        return new Tile[i];
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Tile createFromParcel(Parcel parcel) {
        int zzaU = com.google.android.gms.common.internal.safeparcel.zzb.zzaU(parcel);
        int i = 0;
        int i2 = 0;
        int i3 = 0;
        byte[] bArr = null;
        while (parcel.dataPosition() < zzaU) {
            int readInt = parcel.readInt();
            switch (65535 & readInt) {
                case 1:
                    i3 = com.google.android.gms.common.internal.safeparcel.zzb.zzg(parcel, readInt);
                    break;
                case 2:
                    i2 = com.google.android.gms.common.internal.safeparcel.zzb.zzg(parcel, readInt);
                    break;
                case 3:
                    i = com.google.android.gms.common.internal.safeparcel.zzb.zzg(parcel, readInt);
                    break;
                case 4:
                    int zza = com.google.android.gms.common.internal.safeparcel.zzb.zza(parcel, readInt);
                    int dataPosition = parcel.dataPosition();
                    if (zza != 0) {
                        bArr = parcel.createByteArray();
                        parcel.setDataPosition(zza + dataPosition);
                        break;
                    } else {
                        bArr = null;
                        break;
                    }
                default:
                    com.google.android.gms.common.internal.safeparcel.zzb.zzb(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() != zzaU) {
            throw new zzb.zza(new StringBuilder(37).append("Overread allowed size end=").append(zzaU).toString(), parcel);
        }
        return new Tile(i3, i2, i, bArr);
    }
}
