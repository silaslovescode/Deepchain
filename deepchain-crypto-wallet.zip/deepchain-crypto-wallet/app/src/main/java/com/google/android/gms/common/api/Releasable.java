package com.google.android.gms.common.api;

/* loaded from: classes.dex */
public interface Releasable {
}
