package com.google.android.gms.common.internal;

import android.os.Parcelable;

/* loaded from: classes.dex */
public interface ReflectedParcelable extends Parcelable {
}
