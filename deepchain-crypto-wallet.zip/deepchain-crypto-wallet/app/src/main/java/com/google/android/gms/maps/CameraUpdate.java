package com.google.android.gms.maps;

import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.dynamic.zzd;

/* loaded from: classes.dex */
public final class CameraUpdate {
    final zzd zzbmW;

    /* JADX INFO: Access modifiers changed from: package-private */
    public CameraUpdate(zzd zzdVar) {
        this.zzbmW = (zzd) zzac.zzw(zzdVar);
    }
}
