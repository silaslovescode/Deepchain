package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.zzb;

/* loaded from: classes.dex */
public final class zze implements Parcelable.Creator<LatLng> {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static void zza$7afccc40(LatLng latLng, Parcel parcel) {
        int zzH = com.google.android.gms.common.internal.safeparcel.zzc.zzH(parcel, 20293);
        com.google.android.gms.common.internal.safeparcel.zzc.zzc(parcel, 1, latLng.mVersionCode);
        com.google.android.gms.common.internal.safeparcel.zzc.zza(parcel, 2, latLng.latitude);
        com.google.android.gms.common.internal.safeparcel.zzc.zza(parcel, 3, latLng.longitude);
        com.google.android.gms.common.internal.safeparcel.zzc.zzI(parcel, zzH);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ LatLng[] newArray(int i) {
        return new LatLng[i];
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ LatLng createFromParcel(Parcel parcel) {
        double d = 0.0d;
        int zzaU = com.google.android.gms.common.internal.safeparcel.zzb.zzaU(parcel);
        int i = 0;
        double d2 = 0.0d;
        while (parcel.dataPosition() < zzaU) {
            int readInt = parcel.readInt();
            switch (65535 & readInt) {
                case 1:
                    i = com.google.android.gms.common.internal.safeparcel.zzb.zzg(parcel, readInt);
                    break;
                case 2:
                    d2 = com.google.android.gms.common.internal.safeparcel.zzb.zzn(parcel, readInt);
                    break;
                case 3:
                    d = com.google.android.gms.common.internal.safeparcel.zzb.zzn(parcel, readInt);
                    break;
                default:
                    com.google.android.gms.common.internal.safeparcel.zzb.zzb(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() != zzaU) {
            throw new zzb.zza(new StringBuilder(37).append("Overread allowed size end=").append(zzaU).toString(), parcel);
        }
        return new LatLng(i, d2, d);
    }
}
