package com.google.android.gms.internal;

import android.app.Activity;

/* loaded from: classes.dex */
public class zzaaw {
    protected final zzaax zzaBs;

    public final Activity getActivity() {
        return this.zzaBs.zzwo();
    }
}
