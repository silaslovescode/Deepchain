package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.zzb;

/* loaded from: classes.dex */
public final class zzf implements Parcelable.Creator<MapStyleOptions> {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static void zza$43bb3f2d(MapStyleOptions mapStyleOptions, Parcel parcel) {
        int zzH = com.google.android.gms.common.internal.safeparcel.zzc.zzH(parcel, 20293);
        com.google.android.gms.common.internal.safeparcel.zzc.zzc(parcel, 1, mapStyleOptions.mVersionCode);
        com.google.android.gms.common.internal.safeparcel.zzc.zza$2cfb68bf(parcel, 2, mapStyleOptions.zzbpa);
        com.google.android.gms.common.internal.safeparcel.zzc.zzI(parcel, zzH);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ MapStyleOptions[] newArray(int i) {
        return new MapStyleOptions[i];
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ MapStyleOptions createFromParcel(Parcel parcel) {
        int zzaU = com.google.android.gms.common.internal.safeparcel.zzb.zzaU(parcel);
        int i = 0;
        String str = null;
        while (parcel.dataPosition() < zzaU) {
            int readInt = parcel.readInt();
            switch (65535 & readInt) {
                case 1:
                    i = com.google.android.gms.common.internal.safeparcel.zzb.zzg(parcel, readInt);
                    break;
                case 2:
                    str = com.google.android.gms.common.internal.safeparcel.zzb.zzq(parcel, readInt);
                    break;
                default:
                    com.google.android.gms.common.internal.safeparcel.zzb.zzb(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() != zzaU) {
            throw new zzb.zza(new StringBuilder(37).append("Overread allowed size end=").append(zzaU).toString(), parcel);
        }
        return new MapStyleOptions(i, str);
    }
}
