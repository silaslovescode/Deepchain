package com.google.android.gms.dynamic;

import com.google.android.gms.dynamic.LifecycleDelegate;

/* loaded from: classes.dex */
public interface zzf<T extends LifecycleDelegate> {
    void zza(T t);
}
