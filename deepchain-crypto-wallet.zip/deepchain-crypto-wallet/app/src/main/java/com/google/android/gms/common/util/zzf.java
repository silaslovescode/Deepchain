package com.google.android.gms.common.util;

import android.support.p000v4.util.ArrayMap;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/* loaded from: classes.dex */
public final class zzf {
    public static <K, V> Map<K, V> zzb(K[] kArr, V[] vArr) {
        if (kArr.length != vArr.length) {
            throw new IllegalArgumentException(new StringBuilder(66).append("Key and values array lengths not equal: ").append(kArr.length).append(" != ").append(vArr.length).toString());
        }
        int length = kArr.length;
        switch (length) {
            case 0:
                return Collections.emptyMap();
            case 1:
                return Collections.singletonMap(kArr[0], vArr[0]);
            default:
                Map arrayMap = length <= 32 ? new ArrayMap(length) : new HashMap(length, 1.0f);
                for (int i = 0; i < length; i++) {
                    arrayMap.put(kArr[i], vArr[i]);
                }
                return Collections.unmodifiableMap(arrayMap);
        }
    }
}
