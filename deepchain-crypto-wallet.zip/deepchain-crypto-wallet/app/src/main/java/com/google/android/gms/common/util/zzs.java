package com.google.android.gms.common.util;

import android.os.Build;

/* loaded from: classes.dex */
public final class zzs {
    public static boolean zzyA() {
        return Build.VERSION.SDK_INT >= 14;
    }

    public static boolean zzyG() {
        return Build.VERSION.SDK_INT >= 20;
    }

    public static boolean zzyI() {
        return Build.VERSION.SDK_INT >= 21;
    }
}
