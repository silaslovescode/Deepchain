package com.google.android.gms.maps.internal;

import com.google.android.gms.dynamic.LifecycleDelegate;

/* loaded from: classes.dex */
public interface StreetViewLifecycleDelegate extends LifecycleDelegate {
}
