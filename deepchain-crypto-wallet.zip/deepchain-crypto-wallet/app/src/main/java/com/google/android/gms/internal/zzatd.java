package com.google.android.gms.internal;

import android.support.p002v7.widget.helper.ItemTouchHelper;
import com.google.android.gms.common.internal.zzac;

/* loaded from: classes.dex */
public final class zzatd {
    public static zza<Boolean> zzbqS = zza.zzl("measurement.service_enabled", true);
    public static zza<Boolean> zzbqT = zza.zzl("measurement.service_client_enabled", true);
    public static zza<Boolean> zzbqU = zza.zzl("measurement.log_installs_enabled", false);
    public static zza<String> zzbqV = zza.zzk("measurement.log_tag", "FA", "FA-SVC");
    public static zza<Long> zzbqW = zza.zzb("measurement.ad_id_cache_time", 10000, 10000);
    public static zza<Long> zzbqX = zza.zzb("measurement.monitoring.sample_period_millis", 86400000, 86400000);
    public static zza<Long> zzbqY = zza.zzb("measurement.config.cache_time", 86400000, 3600000);
    public static zza<String> zzbqZ = zza.zzk("measurement.config.url_scheme", "https", "https");
    public static zza<String> zzbra = zza.zzk("measurement.config.url_authority", "app-measurement.com", "app-measurement.com");
    public static zza<Integer> zzbrb = zza.zzB("measurement.upload.max_bundles", 100);
    public static zza<Integer> zzbrc = zza.zzB("measurement.upload.max_batch_size", 65536);
    public static zza<Integer> zzbrd = zza.zzB("measurement.upload.max_bundle_size", 65536);
    public static zza<Integer> zzbre = zza.zzB("measurement.upload.max_events_per_bundle", 1000);
    public static zza<Integer> zzbrf = zza.zzB("measurement.upload.max_events_per_day", 100000);
    public static zza<Integer> zzbrg = zza.zzB("measurement.upload.max_error_events_per_day", 1000);
    public static zza<Integer> zzbrh = zza.zzB("measurement.upload.max_public_events_per_day", 50000);
    public static zza<Integer> zzbri = zza.zzB("measurement.upload.max_conversions_per_day", 500);
    public static zza<Integer> zzbrj = zza.zzB("measurement.upload.max_realtime_events_per_day", 10);
    public static zza<Integer> zzbrk = zza.zzB("measurement.store.max_stored_events_per_app", 100000);
    public static zza<String> zzbrl = zza.zzk("measurement.upload.url", "https://app-measurement.com/a", "https://app-measurement.com/a");
    public static zza<Long> zzbrm = zza.zzb("measurement.upload.backoff_period", 43200000, 43200000);
    public static zza<Long> zzbrn = zza.zzb("measurement.upload.window_interval", 3600000, 3600000);
    public static zza<Long> zzbro = zza.zzb("measurement.upload.interval", 3600000, 3600000);
    public static zza<Long> zzbrp = zza.zzb("measurement.upload.realtime_upload_interval", 10000, 10000);
    public static zza<Long> zzbrq = zza.zzb("measurement.upload.minimum_delay", 500, 500);
    public static zza<Long> zzbrr = zza.zzb("measurement.alarm_manager.minimum_interval", 60000, 60000);
    public static zza<Long> zzbrs = zza.zzb("measurement.upload.stale_data_deletion_interval", 86400000, 86400000);
    public static zza<Long> zzbrt = zza.zzb("measurement.upload.refresh_blacklisted_config_interval", 604800000, 604800000);
    public static zza<Long> zzbru = zza.zzb("measurement.upload.initial_upload_delay_time", 15000, 15000);
    public static zza<Long> zzbrv = zza.zzb("measurement.upload.retry_time", 1800000, 1800000);
    public static zza<Integer> zzbrw = zza.zzB("measurement.upload.retry_count", 6);
    public static zza<Long> zzbrx = zza.zzb("measurement.upload.max_queue_time", 2419200000L, 2419200000L);
    public static zza<Integer> zzbry = zza.zzB("measurement.lifetimevalue.max_currency_tracked", 4);
    public static zza<Integer> zzbrz = zza.zzB("measurement.audience.filter_result_max_count", ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION);
    public static zza<Long> zzbrA = zza.zzb("measurement.service_client.idle_disconnect_millis", 5000, 5000);

    /* loaded from: classes.dex */
    public static final class zza<V> {
        final String zzAH;
        final V zzaeZ;
        private final zzabs<V> zzafa;

        private zza(String str, zzabs<V> zzabsVar, V v) {
            zzac.zzw(zzabsVar);
            this.zzafa = zzabsVar;
            this.zzaeZ = v;
            this.zzAH = str;
        }

        static zza<Long> zzb(String str, long j, long j2) {
            return new zza<>(str, zzabs.zza(str, Long.valueOf(j2)), Long.valueOf(j));
        }

        static zza<String> zzk(String str, String str2, String str3) {
            return new zza<>(str, zzabs.zzA(str, str3), str2);
        }

        public final V get(V v) {
            return v != null ? v : this.zzaeZ;
        }

        static zza<Boolean> zzl(String str, boolean z) {
            return new zza<>(str, zzabs.zzj(str, z), Boolean.valueOf(z));
        }

        static zza<Integer> zzB(String str, int i) {
            return new zza<>(str, zzabs.zza(str, Integer.valueOf(i)), Integer.valueOf(i));
        }
    }
}
