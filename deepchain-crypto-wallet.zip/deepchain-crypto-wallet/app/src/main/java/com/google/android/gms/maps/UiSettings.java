package com.google.android.gms.maps;

import android.os.RemoteException;
import com.google.android.gms.maps.internal.IUiSettingsDelegate;
import com.google.android.gms.maps.model.RuntimeRemoteException;

/* loaded from: classes.dex */
public final class UiSettings {
    private final IUiSettingsDelegate zzboy;

    /* JADX INFO: Access modifiers changed from: package-private */
    public UiSettings(IUiSettingsDelegate iUiSettingsDelegate) {
        this.zzboy = iUiSettingsDelegate;
    }

    public final void setZoomControlsEnabled$1385ff() {
        try {
            this.zzboy.setZoomControlsEnabled(true);
        } catch (RemoteException e) {
            throw new RuntimeRemoteException(e);
        }
    }
}
