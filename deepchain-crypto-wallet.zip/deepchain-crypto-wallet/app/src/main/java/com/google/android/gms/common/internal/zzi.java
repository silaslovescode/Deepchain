package com.google.android.gms.common.internal;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import com.google.android.gms.internal.zzaax;

/* loaded from: classes.dex */
public abstract class zzi implements DialogInterface.OnClickListener {
    public static zzi zza$13498c16(final zzaax zzaaxVar, final Intent intent) {
        return new zzi() { // from class: com.google.android.gms.common.internal.zzi.3
            final /* synthetic */ int val$requestCode = 2;

            @Override // com.google.android.gms.common.internal.zzi
            @TargetApi(11)
            public final void zzxm() {
            }
        };
    }

    public static zzi zza$1da382f5(final Activity activity, final Intent intent) {
        return new zzi() { // from class: com.google.android.gms.common.internal.zzi.1
            final /* synthetic */ int val$requestCode = 2;

            @Override // com.google.android.gms.common.internal.zzi
            public final void zzxm() {
                if (intent != null) {
                    activity.startActivityForResult(intent, this.val$requestCode);
                }
            }
        };
    }

    @Override // android.content.DialogInterface.OnClickListener
    public void onClick(DialogInterface dialogInterface, int i) {
        try {
            zzxm();
        } catch (ActivityNotFoundException e) {
        } finally {
            dialogInterface.dismiss();
        }
    }

    protected abstract void zzxm();
}
