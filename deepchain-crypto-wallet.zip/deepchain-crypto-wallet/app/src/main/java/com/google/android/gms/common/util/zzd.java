package com.google.android.gms.common.util;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import com.google.android.gms.internal.zzacx;

/* loaded from: classes.dex */
public final class zzd {
    @TargetApi(12)
    public static boolean zzx(Context context, String str) {
        if (!(Build.VERSION.SDK_INT >= 12)) {
            return false;
        }
        "com.google.android.gms".equals(str);
        try {
            return (zzacx.zzaQ(context).getApplicationInfo(str, 0).flags & 2097152) != 0;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }
}
