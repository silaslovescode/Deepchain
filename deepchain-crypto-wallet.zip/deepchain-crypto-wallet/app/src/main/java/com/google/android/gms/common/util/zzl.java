package com.google.android.gms.common.util;

import java.util.regex.Pattern;

/* loaded from: classes.dex */
public final class zzl {
    private static Pattern zzaGT = null;

    public static int zzdj(int i) {
        return i / 1000;
    }
}
