package com.google.android.gms.maps;

/* loaded from: classes.dex */
public interface OnStreetViewPanoramaReadyCallback {
}
