package com.google.android.gms.maps.model;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class Tile extends com.google.android.gms.common.internal.safeparcel.zza {
    public static final Parcelable.Creator<Tile> CREATOR = new zzo();
    public final byte[] data;
    public final int height;
    final int mVersionCode;
    public final int width;

    public Tile() {
        this(1, -1, -1, null);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public Tile(int i, int i2, int i3, byte[] bArr) {
        this.mVersionCode = i;
        this.width = i2;
        this.height = i3;
        this.data = bArr;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i) {
        zzo.zza$2bae1718(this, parcel);
    }
}
