package com.google.android.gms.internal;

import android.app.Activity;

/* loaded from: classes.dex */
public interface zzaax {
    Activity zzwo();
}
