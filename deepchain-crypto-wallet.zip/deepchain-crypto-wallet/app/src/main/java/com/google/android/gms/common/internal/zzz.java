package com.google.android.gms.common.internal;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.p000v4.app.NotificationCompat;
import android.util.Log;
import com.google.android.gms.internal.zzacx;

/* loaded from: classes.dex */
public final class zzz {
    private static boolean zzPT;
    private static String zzaEW;
    private static int zzaEX;
    private static Object zztU = new Object();

    public static String zzaD(Context context) {
        zzaF(context);
        return zzaEW;
    }

    public static int zzaE(Context context) {
        zzaF(context);
        return zzaEX;
    }

    private static void zzaF(Context context) {
        Bundle bundle;
        synchronized (zztU) {
            if (zzPT) {
                return;
            }
            zzPT = true;
            try {
                bundle = zzacx.zzaQ(context).getApplicationInfo(context.getPackageName(), NotificationCompat.FLAG_HIGH_PRIORITY).metaData;
            } catch (PackageManager.NameNotFoundException e) {
                Log.wtf("MetadataValueReader", "This should never happen.", e);
            }
            if (bundle == null) {
                return;
            }
            zzaEW = bundle.getString("com.google.app.id");
            zzaEX = bundle.getInt("com.google.android.gms.version");
        }
    }
}
