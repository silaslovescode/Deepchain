package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzc;

/* loaded from: classes.dex */
public final class zzbkq implements Parcelable.Creator<zzbkp> {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static void zza$6ff1229d(zzbkp zzbkpVar, Parcel parcel) {
        int zzH = zzc.zzH(parcel, 20293);
        zzc.zzc(parcel, 1, zzbkpVar.mVersionCode);
        zzc.zza$2cfb68bf(parcel, 2, zzbkpVar.zzbXc);
        zzc.zza$2cfb68bf(parcel, 3, zzbkpVar.zzbUL);
        zzc.zzI(parcel, zzH);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ zzbkp[] newArray(int i) {
        return new zzbkp[i];
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ zzbkp createFromParcel(Parcel parcel) {
        String str = null;
        int zzaU = zzb.zzaU(parcel);
        int i = 0;
        String str2 = null;
        while (parcel.dataPosition() < zzaU) {
            int readInt = parcel.readInt();
            switch (65535 & readInt) {
                case 1:
                    i = zzb.zzg(parcel, readInt);
                    break;
                case 2:
                    str2 = zzb.zzq(parcel, readInt);
                    break;
                case 3:
                    str = zzb.zzq(parcel, readInt);
                    break;
                default:
                    zzb.zzb(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() != zzaU) {
            throw new zzb.zza(new StringBuilder(37).append("Overread allowed size end=").append(zzaU).toString(), parcel);
        }
        return new zzbkp(i, str2, str);
    }
}
