package com.google.android.gms.tasks;

import java.util.Queue;

/* loaded from: classes.dex */
public final class zzg<TResult> {
    private Queue<zzf<TResult>> zzbLD;
    private boolean zzbLE;
    private final Object zzrN = new Object();

    public final void zza$362e213c() {
        synchronized (this.zzrN) {
            if (this.zzbLD == null || this.zzbLE) {
                return;
            }
            this.zzbLE = true;
            while (true) {
                synchronized (this.zzrN) {
                    if (this.zzbLD.poll() == null) {
                        this.zzbLE = false;
                        return;
                    }
                }
            }
        }
    }
}
