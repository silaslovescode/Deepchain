package com.google.android.gms.internal;

import android.graphics.Canvas;
import android.widget.ImageView;

/* loaded from: classes.dex */
public final class zzabu extends ImageView {
    @Override // android.widget.ImageView, android.view.View
    protected final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
    }

    @Override // android.widget.ImageView, android.view.View
    protected final void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
    }
}
