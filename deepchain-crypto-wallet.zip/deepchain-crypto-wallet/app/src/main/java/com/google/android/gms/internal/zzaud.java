package com.google.android.gms.internal;

import com.google.android.gms.common.internal.zzac;

/* loaded from: classes.dex */
final class zzaud {
    final String mName;
    final String zzVQ;
    final Object zzYe;
    final long zzbvd;

    /* JADX INFO: Access modifiers changed from: package-private */
    public zzaud(String str, String str2, long j, Object obj) {
        zzac.zzdv(str);
        zzac.zzdv(str2);
        zzac.zzw(obj);
        this.zzVQ = str;
        this.mName = str2;
        this.zzbvd = j;
        this.zzYe = obj;
    }
}
