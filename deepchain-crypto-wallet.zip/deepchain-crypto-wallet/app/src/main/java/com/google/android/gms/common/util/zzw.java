package com.google.android.gms.common.util;

import java.io.File;

/* loaded from: classes.dex */
public final class zzw {
    public static synchronized File zze(File file) {
        synchronized (zzw.class) {
            if (!file.exists() && !file.mkdirs() && !file.exists()) {
                String valueOf = String.valueOf(file.getPath());
                if (valueOf.length() != 0) {
                    "Unable to create no-backup dir ".concat(valueOf);
                } else {
                    new String("Unable to create no-backup dir ");
                }
                file = null;
            }
        }
        return file;
    }
}
