package android.support.p000v4.p001os;

import android.os.Build;

/* renamed from: android.support.v4.os.BuildCompat */
/* loaded from: classes.dex */
public final class BuildCompat {
    public static boolean isAtLeastN() {
        return Build.VERSION.SDK_INT >= 24;
    }
}
