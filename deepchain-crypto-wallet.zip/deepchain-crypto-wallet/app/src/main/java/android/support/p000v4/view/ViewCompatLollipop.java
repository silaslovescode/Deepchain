package android.support.p000v4.view;

import android.annotation.TargetApi;
import android.graphics.Rect;
import android.view.View;
import android.view.WindowInsets;

@TargetApi(21)
/* renamed from: android.support.v4.view.ViewCompatLollipop */
/* loaded from: classes.dex */
final class ViewCompatLollipop {
    private static ThreadLocal<Rect> sThreadLocalRect;

    /* renamed from: android.support.v4.view.ViewCompatLollipop$OnApplyWindowInsetsListenerBridge */
    /* loaded from: classes.dex */
    public interface OnApplyWindowInsetsListenerBridge {
        Object onApplyWindowInsets(View view, Object obj);
    }

    public static void setOnApplyWindowInsetsListener(View view, final OnApplyWindowInsetsListenerBridge bridge) {
        if (bridge == null) {
            view.setOnApplyWindowInsetsListener(null);
        } else {
            view.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() { // from class: android.support.v4.view.ViewCompatLollipop.1
                @Override // android.view.View.OnApplyWindowInsetsListener
                public final WindowInsets onApplyWindowInsets(View view2, WindowInsets insets) {
                    return (WindowInsets) OnApplyWindowInsetsListenerBridge.this.onApplyWindowInsets(view2, insets);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static Rect getEmptyTempRect() {
        if (sThreadLocalRect == null) {
            sThreadLocalRect = new ThreadLocal<>();
        }
        Rect rect = sThreadLocalRect.get();
        if (rect == null) {
            rect = new Rect();
            sThreadLocalRect.set(rect);
        }
        rect.setEmpty();
        return rect;
    }
}
