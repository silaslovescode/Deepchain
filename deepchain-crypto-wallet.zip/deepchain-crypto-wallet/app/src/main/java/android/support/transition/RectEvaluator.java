package android.support.transition;

import android.animation.TypeEvaluator;
import android.annotation.TargetApi;
import android.graphics.Rect;

@TargetApi(14)
/* loaded from: classes.dex */
final class RectEvaluator implements TypeEvaluator<Rect> {
    private Rect mRect;

    @Override // android.animation.TypeEvaluator
    public final /* bridge */ /* synthetic */ Rect evaluate(float f, Rect rect, Rect rect2) {
        Rect rect3 = rect;
        Rect rect4 = rect2;
        int i = ((int) ((rect4.left - rect3.left) * f)) + rect3.left;
        int i2 = ((int) ((rect4.top - rect3.top) * f)) + rect3.top;
        int i3 = ((int) ((rect4.right - rect3.right) * f)) + rect3.right;
        int i4 = ((int) ((rect4.bottom - rect3.bottom) * f)) + rect3.bottom;
        if (this.mRect == null) {
            return new Rect(i, i2, i3, i4);
        }
        this.mRect.set(i, i2, i3, i4);
        return this.mRect;
    }
}
