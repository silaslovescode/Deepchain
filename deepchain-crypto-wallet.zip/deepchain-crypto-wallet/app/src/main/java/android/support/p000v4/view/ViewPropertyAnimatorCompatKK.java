package android.support.p000v4.view;

import android.annotation.TargetApi;

@TargetApi(19)
/* renamed from: android.support.v4.view.ViewPropertyAnimatorCompatKK */
/* loaded from: classes.dex */
final class ViewPropertyAnimatorCompatKK {
}
