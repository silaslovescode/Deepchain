package android.support.p000v4.view;

import android.os.Build;
import android.support.p000v4.app.NotificationCompat;
import android.view.KeyEvent;

/* renamed from: android.support.v4.view.KeyEventCompat */
/* loaded from: classes.dex */
public final class KeyEventCompat {
    static final KeyEventVersionImpl IMPL;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: android.support.v4.view.KeyEventCompat$KeyEventVersionImpl */
    /* loaded from: classes.dex */
    public interface KeyEventVersionImpl {
        boolean isCtrlPressed(KeyEvent keyEvent);

        boolean metaStateHasModifiers$255f299(int i);

        boolean metaStateHasNoModifiers(int i);
    }

    /* renamed from: android.support.v4.view.KeyEventCompat$BaseKeyEventVersionImpl */
    /* loaded from: classes.dex */
    static class BaseKeyEventVersionImpl implements KeyEventVersionImpl {
        BaseKeyEventVersionImpl() {
        }

        private static int metaStateFilterDirectionalModifiers$2e71581f(int metaState, int basic, int left, int right) {
            boolean wantLeftOrRight = true;
            boolean wantBasic = (basic & 1) != 0;
            int directional = left | right;
            if ((directional & 1) == 0) {
                wantLeftOrRight = false;
            }
            if (wantBasic) {
                if (wantLeftOrRight) {
                    throw new IllegalArgumentException("bad arguments");
                }
                return metaState & (directional ^ (-1));
            } else if (wantLeftOrRight) {
                return metaState & (basic ^ (-1));
            } else {
                return metaState;
            }
        }

        public int normalizeMetaState(int metaState) {
            if ((metaState & 192) != 0) {
                metaState |= 1;
            }
            if ((metaState & 48) != 0) {
                metaState |= 2;
            }
            return metaState & 247;
        }

        @Override // android.support.p000v4.view.KeyEventCompat.KeyEventVersionImpl
        public boolean metaStateHasModifiers$255f299(int metaState) {
            return metaStateFilterDirectionalModifiers$2e71581f(metaStateFilterDirectionalModifiers$2e71581f(normalizeMetaState(metaState) & 247, 1, 64, NotificationCompat.FLAG_HIGH_PRIORITY), 2, 16, 32) == 1;
        }

        @Override // android.support.p000v4.view.KeyEventCompat.KeyEventVersionImpl
        public boolean metaStateHasNoModifiers(int metaState) {
            return (normalizeMetaState(metaState) & 247) == 0;
        }

        @Override // android.support.p000v4.view.KeyEventCompat.KeyEventVersionImpl
        public boolean isCtrlPressed(KeyEvent event) {
            return false;
        }
    }

    /* renamed from: android.support.v4.view.KeyEventCompat$HoneycombKeyEventVersionImpl */
    /* loaded from: classes.dex */
    static class HoneycombKeyEventVersionImpl extends BaseKeyEventVersionImpl {
        HoneycombKeyEventVersionImpl() {
        }

        @Override // android.support.p000v4.view.KeyEventCompat.BaseKeyEventVersionImpl
        public final int normalizeMetaState(int metaState) {
            return KeyEvent.normalizeMetaState(metaState);
        }

        @Override // android.support.p000v4.view.KeyEventCompat.BaseKeyEventVersionImpl, android.support.p000v4.view.KeyEventCompat.KeyEventVersionImpl
        public final boolean metaStateHasModifiers$255f299(int metaState) {
            return KeyEvent.metaStateHasModifiers(metaState, 1);
        }

        @Override // android.support.p000v4.view.KeyEventCompat.BaseKeyEventVersionImpl, android.support.p000v4.view.KeyEventCompat.KeyEventVersionImpl
        public final boolean metaStateHasNoModifiers(int metaState) {
            return KeyEvent.metaStateHasNoModifiers(metaState);
        }

        @Override // android.support.p000v4.view.KeyEventCompat.BaseKeyEventVersionImpl, android.support.p000v4.view.KeyEventCompat.KeyEventVersionImpl
        public final boolean isCtrlPressed(KeyEvent event) {
            return event.isCtrlPressed();
        }
    }

    static {
        if (Build.VERSION.SDK_INT >= 11) {
            IMPL = new HoneycombKeyEventVersionImpl();
        } else {
            IMPL = new BaseKeyEventVersionImpl();
        }
    }

    public static boolean hasNoModifiers(KeyEvent event) {
        return IMPL.metaStateHasNoModifiers(event.getMetaState());
    }

    public static boolean isCtrlPressed(KeyEvent event) {
        return IMPL.isCtrlPressed(event);
    }
}
