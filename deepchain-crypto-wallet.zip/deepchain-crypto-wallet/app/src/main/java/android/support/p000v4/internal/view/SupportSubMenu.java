package android.support.p000v4.internal.view;

import android.view.SubMenu;

/* renamed from: android.support.v4.internal.view.SupportSubMenu */
/* loaded from: classes.dex */
public interface SupportSubMenu extends SupportMenu, SubMenu {
}
