package android.support.p000v4.view;

import android.annotation.TargetApi;

@TargetApi(16)
/* renamed from: android.support.v4.view.ViewPropertyAnimatorCompatJB */
/* loaded from: classes.dex */
final class ViewPropertyAnimatorCompatJB {
}
