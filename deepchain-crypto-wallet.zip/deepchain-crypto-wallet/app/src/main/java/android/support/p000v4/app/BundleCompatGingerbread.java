package android.support.p000v4.app;

import android.annotation.TargetApi;
import android.os.Bundle;
import android.os.IBinder;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

@TargetApi(9)
/* renamed from: android.support.v4.app.BundleCompatGingerbread */
/* loaded from: classes.dex */
final class BundleCompatGingerbread {
    private static Method sGetIBinderMethod;
    private static boolean sGetIBinderMethodFetched;

    public static IBinder getBinder(Bundle bundle, String key) {
        if (!sGetIBinderMethodFetched) {
            try {
                Method method = Bundle.class.getMethod("getIBinder", String.class);
                sGetIBinderMethod = method;
                method.setAccessible(true);
            } catch (NoSuchMethodException e) {
            }
            sGetIBinderMethodFetched = true;
        }
        if (sGetIBinderMethod != null) {
            try {
                return (IBinder) sGetIBinderMethod.invoke(bundle, key);
            } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e2) {
                sGetIBinderMethod = null;
            }
        }
        return null;
    }
}
