package android.support.transition;

import android.view.ViewGroup;

/* loaded from: classes.dex */
abstract class TransitionManagerStaticsImpl {
    public abstract void beginDelayedTransition(ViewGroup viewGroup, TransitionImpl transitionImpl);
}
