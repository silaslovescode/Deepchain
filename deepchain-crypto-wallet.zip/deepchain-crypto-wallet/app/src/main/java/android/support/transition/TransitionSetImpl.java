package android.support.transition;

/* loaded from: classes.dex */
interface TransitionSetImpl {
    TransitionSetImpl addTransition(TransitionImpl transitionImpl);

    TransitionSetImpl setOrdering(int i);
}
