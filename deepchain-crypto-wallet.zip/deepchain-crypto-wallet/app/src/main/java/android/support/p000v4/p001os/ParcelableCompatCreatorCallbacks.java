package android.support.p000v4.p001os;

import android.os.Parcel;

/* renamed from: android.support.v4.os.ParcelableCompatCreatorCallbacks */
/* loaded from: classes.dex */
public interface ParcelableCompatCreatorCallbacks<T> {
    /* renamed from: createFromParcel */
    T mo94createFromParcel(Parcel parcel, ClassLoader classLoader);

    /* renamed from: newArray */
    T[] mo95newArray(int i);
}
