package android.support.p000v4.animation;

import android.view.View;

/* renamed from: android.support.v4.animation.AnimatorProvider */
/* loaded from: classes.dex */
interface AnimatorProvider {
    void clearInterpolator(View view);

    ValueAnimatorCompat emptyValueAnimator();
}
