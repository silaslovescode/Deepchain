package android.databinding;

import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public class CallbackRegistry<C, T, A> implements Cloneable {
    private List<C> mCallbacks = new ArrayList();
    private long mFirst64Removed = 0;
    private int mNotificationLevel;
    private final NotifierCallback<C, T, A> mNotifier;
    private long[] mRemainderRemoved;

    /* loaded from: classes.dex */
    public static abstract class NotifierCallback<C, T, A> {
        public abstract void onNotifyCallback$3215a152(C c, T t, int i);
    }

    public CallbackRegistry(NotifierCallback<C, T, A> notifier) {
        this.mNotifier = notifier;
    }

    public final synchronized void notifyCallbacks$6c297392(T sender, int arg) {
        this.mNotificationLevel++;
        int size = this.mCallbacks.size();
        int length = this.mRemainderRemoved == null ? -1 : this.mRemainderRemoved.length - 1;
        notifyRemainder(sender, arg, null, length);
        notifyCallbacks$15fe1736(sender, arg, (length + 2) * 64, size, 0L);
        this.mNotificationLevel--;
        if (this.mNotificationLevel == 0) {
            if (this.mRemainderRemoved != null) {
                for (int i = this.mRemainderRemoved.length - 1; i >= 0; i--) {
                    long removedBits = this.mRemainderRemoved[i];
                    if (removedBits != 0) {
                        removeRemovedCallbacks((i + 1) * 64, removedBits);
                        this.mRemainderRemoved[i] = 0;
                    }
                }
            }
            if (this.mFirst64Removed != 0) {
                removeRemovedCallbacks(0, this.mFirst64Removed);
                this.mFirst64Removed = 0L;
            }
        }
    }

    private void notifyRemainder(T sender, int arg, A arg2, int remainderIndex) {
        if (remainderIndex >= 0) {
            long bits = this.mRemainderRemoved[remainderIndex];
            int startIndex = (remainderIndex + 1) * 64;
            int endIndex = Math.min(this.mCallbacks.size(), startIndex + 64);
            notifyRemainder(sender, arg, arg2, remainderIndex - 1);
            notifyCallbacks$15fe1736(sender, arg, startIndex, endIndex, bits);
            return;
        }
        notifyCallbacks$15fe1736(sender, arg, 0, Math.min(64, this.mCallbacks.size()), this.mFirst64Removed);
    }

    private void notifyCallbacks$15fe1736(T sender, int arg, int startIndex, int endIndex, long bits) {
        long bitMask = 1;
        for (int i = startIndex; i < endIndex; i++) {
            if ((bits & bitMask) == 0) {
                this.mNotifier.onNotifyCallback$3215a152(this.mCallbacks.get(i), sender, arg);
            }
            bitMask <<= 1;
        }
    }

    public final synchronized void add(C callback) {
        if (callback == null) {
            throw new IllegalArgumentException("callback cannot be null");
        }
        int index = this.mCallbacks.lastIndexOf(callback);
        if (index < 0 || isRemoved(index)) {
            this.mCallbacks.add(callback);
        }
    }

    private boolean isRemoved(int index) {
        int maskIndex;
        if (index < 64) {
            long bitMask = 1 << index;
            return (this.mFirst64Removed & bitMask) != 0;
        }
        if (this.mRemainderRemoved != null && (index / 64) - 1 < this.mRemainderRemoved.length) {
            long bits = this.mRemainderRemoved[maskIndex];
            long bitMask2 = 1 << (index % 64);
            return (bits & bitMask2) != 0;
        }
        return false;
    }

    private void removeRemovedCallbacks(int startIndex, long removed) {
        int endIndex = startIndex + 64;
        long bitMask = Long.MIN_VALUE;
        for (int i = endIndex - 1; i >= startIndex; i--) {
            if ((removed & bitMask) != 0) {
                this.mCallbacks.remove(i);
            }
            bitMask >>>= 1;
        }
    }

    public final synchronized void remove(C callback) {
        if (this.mNotificationLevel == 0) {
            this.mCallbacks.remove(callback);
        } else {
            int index = this.mCallbacks.lastIndexOf(callback);
            if (index >= 0) {
                if (index < 64) {
                    this.mFirst64Removed = (1 << index) | this.mFirst64Removed;
                } else {
                    int i = (index / 64) - 1;
                    if (this.mRemainderRemoved == null) {
                        this.mRemainderRemoved = new long[this.mCallbacks.size() / 64];
                    } else if (this.mRemainderRemoved.length <= i) {
                        long[] jArr = new long[this.mCallbacks.size() / 64];
                        System.arraycopy(this.mRemainderRemoved, 0, jArr, 0, this.mRemainderRemoved.length);
                        this.mRemainderRemoved = jArr;
                    }
                    long[] jArr2 = this.mRemainderRemoved;
                    jArr2[i] = (1 << (index % 64)) | jArr2[i];
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* renamed from: clone */
    public synchronized CallbackRegistry<C, T, A> m36clone() {
        CallbackRegistry<C, T, A> clone;
        clone = null;
        try {
            clone = (CallbackRegistry) super.clone();
            clone.mFirst64Removed = 0L;
            clone.mRemainderRemoved = null;
            clone.mNotificationLevel = 0;
            clone.mCallbacks = new ArrayList();
            int numListeners = this.mCallbacks.size();
            for (int i = 0; i < numListeners; i++) {
                if (!isRemoved(i)) {
                    clone.mCallbacks.add(this.mCallbacks.get(i));
                }
            }
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        return clone;
    }
}
