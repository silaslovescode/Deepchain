package android.databinding.adapters;

import android.text.Spanned;
import android.widget.TextView;

/* loaded from: classes.dex */
public final class TextViewBindingAdapter {
    public static void setText(TextView view, CharSequence text) {
        boolean z = true;
        CharSequence oldText = view.getText();
        if (text != oldText) {
            if (text != null || oldText.length() != 0) {
                if (text instanceof Spanned) {
                    if (text.equals(oldText)) {
                        return;
                    }
                } else {
                    if ((text == null) == (oldText == null)) {
                        if (text != null) {
                            int length = text.length();
                            if (length == oldText.length()) {
                                for (int i = 0; i < length; i++) {
                                    if (text.charAt(i) != oldText.charAt(i)) {
                                        break;
                                    }
                                }
                            }
                        }
                        z = false;
                    }
                    if (!z) {
                        return;
                    }
                }
                view.setText(text);
            }
        }
    }
}
