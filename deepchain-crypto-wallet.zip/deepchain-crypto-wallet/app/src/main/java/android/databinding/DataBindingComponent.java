package android.databinding;

/* loaded from: classes.dex */
public interface DataBindingComponent {
}
