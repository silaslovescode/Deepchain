package com.google.android.gms.internal;

/* loaded from: classes.dex */
public final class zzaaz<L> {
    volatile L mListener;

    /* loaded from: classes.dex */
    public static final class zzb<L> {
        private final L mListener;
        private final String zzaBB;

        public final boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof zzb)) {
                return false;
            }
            zzb zzbVar = (zzb) obj;
            return this.mListener == zzbVar.mListener && this.zzaBB.equals(zzbVar.zzaBB);
        }

        public final int hashCode() {
            return (System.identityHashCode(this.mListener) * 31) + this.zzaBB.hashCode();
        }
    }
}
