package com.google.android.gms.common.internal.safeparcel;

/* loaded from: classes.dex */
public abstract class zza implements SafeParcelable {
    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }
}
