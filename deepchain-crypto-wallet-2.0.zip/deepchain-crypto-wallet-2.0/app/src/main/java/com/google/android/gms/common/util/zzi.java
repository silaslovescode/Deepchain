package com.google.android.gms.common.util;

import android.annotation.TargetApi;
import android.content.Context;
import android.os.Build;

/* loaded from: classes.dex */
public final class zzi {
    private static Boolean zzaGN;
    public static Boolean zzaGP;

    @TargetApi(24)
    public static boolean zzaJ(Context context) {
        if (!(Build.VERSION.SDK_INT >= 24)) {
            if (zzaGN == null) {
                zzaGN = Boolean.valueOf(zzs.zzyG() && context.getPackageManager().hasSystemFeature("android.hardware.type.watch"));
            }
            if (zzaGN.booleanValue()) {
                return true;
            }
        }
        return false;
    }
}
