package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzc;

/* loaded from: classes.dex */
public final class zzauc implements Parcelable.Creator<zzaub> {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static void zza$ffd43e4(zzaub zzaubVar, Parcel parcel) {
        int zzH = zzc.zzH(parcel, 20293);
        zzc.zzc(parcel, 1, zzaubVar.versionCode);
        zzc.zza$2cfb68bf(parcel, 2, zzaubVar.name);
        zzc.zza(parcel, 3, zzaubVar.zzbuZ);
        Long l = zzaubVar.zzbva;
        if (l != null) {
            zzc.zzb(parcel, 4, 8);
            parcel.writeLong(l.longValue());
        }
        zzc.zza$796a1efa(parcel, 5, zzaubVar.zzbvb);
        zzc.zza$2cfb68bf(parcel, 6, zzaubVar.zzaFy);
        zzc.zza$2cfb68bf(parcel, 7, zzaubVar.zzbqQ);
        Double d = zzaubVar.zzbvc;
        if (d != null) {
            zzc.zzb(parcel, 8, 8);
            parcel.writeDouble(d.doubleValue());
        }
        zzc.zzI(parcel, zzH);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ zzaub[] newArray(int i) {
        return new zzaub[i];
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ zzaub createFromParcel(Parcel parcel) {
        int zzaU = zzb.zzaU(parcel);
        int i = 0;
        String str = null;
        long j = 0;
        Long l = null;
        Float f = null;
        String str2 = null;
        String str3 = null;
        Double d = null;
        while (parcel.dataPosition() < zzaU) {
            int readInt = parcel.readInt();
            switch (65535 & readInt) {
                case 1:
                    i = zzb.zzg(parcel, readInt);
                    break;
                case 2:
                    str = zzb.zzq(parcel, readInt);
                    break;
                case 3:
                    j = zzb.zzi(parcel, readInt);
                    break;
                case 4:
                    int zza = zzb.zza(parcel, readInt);
                    if (zza != 0) {
                        zzb.zza$ae3cd4b(parcel, zza, 8);
                        l = Long.valueOf(parcel.readLong());
                        break;
                    } else {
                        l = null;
                        break;
                    }
                case 5:
                    f = zzb.zzm(parcel, readInt);
                    break;
                case 6:
                    str2 = zzb.zzq(parcel, readInt);
                    break;
                case 7:
                    str3 = zzb.zzq(parcel, readInt);
                    break;
                case 8:
                    int zza2 = zzb.zza(parcel, readInt);
                    if (zza2 != 0) {
                        zzb.zza$ae3cd4b(parcel, zza2, 8);
                        d = Double.valueOf(parcel.readDouble());
                        break;
                    } else {
                        d = null;
                        break;
                    }
                default:
                    zzb.zzb(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() != zzaU) {
            throw new zzb.zza(new StringBuilder(37).append("Overread allowed size end=").append(zzaU).toString(), parcel);
        }
        return new zzaub(i, str, j, l, f, str2, str3, d);
    }
}
