package com.google.android.gms.internal;

import com.google.android.gms.common.internal.zzac;
import com.google.android.gms.common.util.zze;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public final class zzatz {
    long zzKH;
    final zze zzuI;

    public zzatz(zze zzeVar) {
        zzac.zzw(zzeVar);
        this.zzuI = zzeVar;
    }

    public final void start() {
        this.zzKH = this.zzuI.elapsedRealtime();
    }
}
