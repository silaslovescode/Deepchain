package com.google.android.gms.iid;

import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import com.google.android.gms.common.internal.ReflectedParcelable;
import com.google.android.gms.iid.zzb;

/* loaded from: classes.dex */
public class MessengerCompat implements ReflectedParcelable {
    public static final Parcelable.Creator<MessengerCompat> CREATOR = new Parcelable.Creator<MessengerCompat>() { // from class: com.google.android.gms.iid.MessengerCompat.1
        @Override // android.os.Parcelable.Creator
        public final /* synthetic */ MessengerCompat[] newArray(int i) {
            return new MessengerCompat[i];
        }

        @Override // android.os.Parcelable.Creator
        public final /* synthetic */ MessengerCompat createFromParcel(Parcel parcel) {
            IBinder readStrongBinder = parcel.readStrongBinder();
            if (readStrongBinder != null) {
                return new MessengerCompat(readStrongBinder);
            }
            return null;
        }
    };
    public Messenger zzbho;
    public zzb zzbhp;

    /* loaded from: classes.dex */
    private final class zza extends zzb.zza {
        Handler handler;

        zza(Handler handler) {
            this.handler = handler;
        }

        @Override // com.google.android.gms.iid.zzb
        public final void send(Message message) throws RemoteException {
            message.arg2 = Binder.getCallingUid();
            this.handler.dispatchMessage(message);
        }
    }

    public MessengerCompat(Handler handler) {
        if (Build.VERSION.SDK_INT >= 21) {
            this.zzbho = new Messenger(handler);
        } else {
            this.zzbhp = new zza(handler);
        }
    }

    public MessengerCompat(IBinder iBinder) {
        if (Build.VERSION.SDK_INT >= 21) {
            this.zzbho = new Messenger(iBinder);
        } else {
            this.zzbhp = zzb.zza.zzcZ(iBinder);
        }
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        try {
            return getBinder().equals(((MessengerCompat) obj).getBinder());
        } catch (ClassCastException e) {
            return false;
        }
    }

    public final IBinder getBinder() {
        return this.zzbho != null ? this.zzbho.getBinder() : this.zzbhp.asBinder();
    }

    public int hashCode() {
        return getBinder().hashCode();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        if (this.zzbho != null) {
            parcel.writeStrongBinder(this.zzbho.getBinder());
        } else {
            parcel.writeStrongBinder(this.zzbhp.asBinder());
        }
    }

    public static int zzc(Message message) {
        return Build.VERSION.SDK_INT >= 21 ? message.sendingUid : message.arg2;
    }
}
