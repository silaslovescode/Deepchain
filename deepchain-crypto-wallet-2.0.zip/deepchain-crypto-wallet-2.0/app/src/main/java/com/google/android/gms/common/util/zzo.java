package com.google.android.gms.common.util;

import java.io.Closeable;
import java.io.IOException;

/* loaded from: classes.dex */
public final class zzo {
    public static void zzb(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException e) {
            }
        }
    }
}
