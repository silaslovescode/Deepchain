package com.google.android.gms.internal;

import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.zzb;

/* loaded from: classes.dex */
public abstract class zzabe<A extends Api.zzb, L> {
    final zzaaz<L> zzaBG;
}
