package com.google.android.gms.internal;

/* loaded from: classes.dex */
public final class zzbko extends Exception {
    public zzbko(String str) {
        super(str);
    }
}
