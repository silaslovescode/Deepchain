package com.google.android.gms.tasks;

import com.google.android.gms.common.internal.zzac;

/* loaded from: classes.dex */
public final class zzh<TResult> extends Task<TResult> {
    public boolean zzbLI;
    public TResult zzbLJ;
    public Exception zzbLK;
    public final Object zzrN = new Object();
    public final zzg<TResult> zzbLH = new zzg<>();

    public final boolean trySetException(Exception exc) {
        boolean z = true;
        zzac.zzb(exc, "Exception must not be null");
        synchronized (this.zzrN) {
            if (this.zzbLI) {
                z = false;
            } else {
                this.zzbLI = true;
                this.zzbLK = exc;
                this.zzbLH.zza$362e213c();
            }
        }
        return z;
    }

    public final void zzSf() {
        zzac.zza(!this.zzbLI, "Task is already complete");
    }
}
