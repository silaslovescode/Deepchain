package com.google.android.gms.common.api;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.zzb;

/* loaded from: classes.dex */
public final class zzg implements Parcelable.Creator<Scope> {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static void zza$514aa83(Scope scope, Parcel parcel) {
        int zzH = com.google.android.gms.common.internal.safeparcel.zzc.zzH(parcel, 20293);
        com.google.android.gms.common.internal.safeparcel.zzc.zzc(parcel, 1, scope.mVersionCode);
        com.google.android.gms.common.internal.safeparcel.zzc.zza$2cfb68bf(parcel, 2, scope.zzayg);
        com.google.android.gms.common.internal.safeparcel.zzc.zzI(parcel, zzH);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Scope[] newArray(int i) {
        return new Scope[i];
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ Scope createFromParcel(Parcel parcel) {
        int zzaU = com.google.android.gms.common.internal.safeparcel.zzb.zzaU(parcel);
        int i = 0;
        String str = null;
        while (parcel.dataPosition() < zzaU) {
            int readInt = parcel.readInt();
            switch (65535 & readInt) {
                case 1:
                    i = com.google.android.gms.common.internal.safeparcel.zzb.zzg(parcel, readInt);
                    break;
                case 2:
                    str = com.google.android.gms.common.internal.safeparcel.zzb.zzq(parcel, readInt);
                    break;
                default:
                    com.google.android.gms.common.internal.safeparcel.zzb.zzb(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() != zzaU) {
            throw new zzb.zza(new StringBuilder(37).append("Overread allowed size end=").append(zzaU).toString(), parcel);
        }
        return new Scope(i, str);
    }
}
