package com.google.android.gms.common.stats;

import android.support.p000v4.util.SimpleArrayMap;

/* loaded from: classes.dex */
public final class zzd {
    private final long zzaGr;
    private final int zzaGs;
    private final SimpleArrayMap<String, Long> zzaGt;

    public zzd() {
        this.zzaGr = 60000L;
        this.zzaGs = 10;
        this.zzaGt = new SimpleArrayMap<>(10);
    }

    public zzd(long j) {
        this.zzaGr = j;
        this.zzaGs = 1024;
        this.zzaGt = new SimpleArrayMap<>();
    }
}
