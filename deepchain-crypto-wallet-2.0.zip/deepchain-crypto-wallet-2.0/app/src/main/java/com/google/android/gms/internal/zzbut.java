package com.google.android.gms.internal;

import java.io.IOException;

/* loaded from: classes.dex */
public abstract class zzbut {
    protected volatile int zzcsg = -1;

    public String toString() {
        return zzbuu.zzg(this);
    }

    public void zza(zzbum zzbumVar) throws IOException {
    }

    public final int zzacY() {
        if (this.zzcsg < 0) {
            zzacZ();
        }
        return this.zzcsg;
    }

    public final int zzacZ() {
        int zzv = zzv();
        this.zzcsg = zzv;
        return zzv;
    }

    public abstract zzbut zzb(zzbul zzbulVar) throws IOException;

    /* JADX INFO: Access modifiers changed from: protected */
    public int zzv() {
        return 0;
    }

    public /* synthetic */ Object clone() throws CloneNotSupportedException {
        return (zzbut) super.clone();
    }
}
