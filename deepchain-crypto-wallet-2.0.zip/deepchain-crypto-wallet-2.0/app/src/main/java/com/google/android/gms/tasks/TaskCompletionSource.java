package com.google.android.gms.tasks;

/* loaded from: classes.dex */
public final class TaskCompletionSource<TResult> {
    public final zzh<TResult> zzbLF = new zzh<>();

    public final boolean trySetException(Exception exc) {
        return this.zzbLF.trySetException(exc);
    }
}
