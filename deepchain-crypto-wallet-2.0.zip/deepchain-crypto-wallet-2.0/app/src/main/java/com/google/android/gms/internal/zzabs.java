package com.google.android.gms.internal;

import android.os.Binder;

/* loaded from: classes.dex */
public abstract class zzabs<T> {
    protected final String zzAH;
    protected final T zzAI;
    private T zzaCf = null;
    private static final Object zztU = new Object();
    private static zza zzaCd = null;
    private static int zzaCe = 0;
    private static String READ_PERMISSION = "com.google.android.providers.gsf.permission.READ_GSERVICES";

    /* loaded from: classes.dex */
    private interface zza {
        Long getLong$4885d6e9();

        String getString$7157d249();

        Boolean zza$6de378eb();

        Integer zzb$1b7f1b3f();
    }

    protected zzabs(String str, T t) {
        this.zzAH = str;
        this.zzAI = t;
    }

    public static zzabs<String> zzA(String str, String str2) {
        return new zzabs<String>(str, str2) { // from class: com.google.android.gms.internal.zzabs.5
            @Override // com.google.android.gms.internal.zzabs
            protected final /* synthetic */ String zzdd$9543ced() {
                zza zzaVar = null;
                return zzaVar.getString$7157d249();
            }
        };
    }

    public static zzabs<Integer> zza(String str, Integer num) {
        return new zzabs<Integer>(str, num) { // from class: com.google.android.gms.internal.zzabs.3
            @Override // com.google.android.gms.internal.zzabs
            protected final /* synthetic */ Integer zzdd$9543ced() {
                zza zzaVar = null;
                return zzaVar.zzb$1b7f1b3f();
            }
        };
    }

    public static zzabs<Long> zza(String str, Long l) {
        return new zzabs<Long>(str, l) { // from class: com.google.android.gms.internal.zzabs.2
            @Override // com.google.android.gms.internal.zzabs
            protected final /* synthetic */ Long zzdd$9543ced() {
                zza zzaVar = null;
                return zzaVar.getLong$4885d6e9();
            }
        };
    }

    public static zzabs<Boolean> zzj(String str, boolean z) {
        return new zzabs<Boolean>(str, Boolean.valueOf(z)) { // from class: com.google.android.gms.internal.zzabs.1
            @Override // com.google.android.gms.internal.zzabs
            protected final /* synthetic */ Boolean zzdd$9543ced() {
                zza zzaVar = null;
                return zzaVar.zza$6de378eb();
            }
        };
    }

    public final T get() {
        try {
            return zzdd$9543ced();
        } catch (SecurityException e) {
            long clearCallingIdentity = Binder.clearCallingIdentity();
            try {
                return zzdd$9543ced();
            } finally {
                Binder.restoreCallingIdentity(clearCallingIdentity);
            }
        }
    }

    protected abstract T zzdd$9543ced();
}
