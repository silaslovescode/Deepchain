package com.google.android.gms.internal;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzc;

/* loaded from: classes.dex */
public final class zzata implements Parcelable.Creator<zzasz> {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static void zza$783878fe(zzasz zzaszVar, Parcel parcel) {
        int zzH = zzc.zzH(parcel, 20293);
        zzc.zzc(parcel, 1, zzaszVar.versionCode);
        zzc.zza$f7bef55(parcel, 2, zzaszVar.zzKY());
        zzc.zzI(parcel, zzH);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ zzasz[] newArray(int i) {
        return new zzasz[i];
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ zzasz createFromParcel(Parcel parcel) {
        int zzaU = zzb.zzaU(parcel);
        int i = 0;
        Bundle bundle = null;
        while (parcel.dataPosition() < zzaU) {
            int readInt = parcel.readInt();
            switch (65535 & readInt) {
                case 1:
                    i = zzb.zzg(parcel, readInt);
                    break;
                case 2:
                    bundle = zzb.zzs(parcel, readInt);
                    break;
                default:
                    zzb.zzb(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() != zzaU) {
            throw new zzb.zza(new StringBuilder(37).append("Overread allowed size end=").append(zzaU).toString(), parcel);
        }
        return new zzasz(i, bundle);
    }
}
