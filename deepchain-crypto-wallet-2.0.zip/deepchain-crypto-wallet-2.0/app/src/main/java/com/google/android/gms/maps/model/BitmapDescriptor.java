package com.google.android.gms.maps.model;

import com.google.android.gms.common.internal.zzac;

/* loaded from: classes.dex */
public final class BitmapDescriptor {
    final com.google.android.gms.dynamic.zzd zzbmW;

    public BitmapDescriptor(com.google.android.gms.dynamic.zzd zzdVar) {
        this.zzbmW = (com.google.android.gms.dynamic.zzd) zzac.zzw(zzdVar);
    }
}
