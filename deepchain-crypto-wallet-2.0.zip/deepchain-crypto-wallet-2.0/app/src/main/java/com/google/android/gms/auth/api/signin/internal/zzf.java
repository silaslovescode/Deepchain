package com.google.android.gms.auth.api.signin.internal;

/* loaded from: classes.dex */
public final class zzf {
    static int zzajy = 31;
    public int zzajz = 1;

    public final zzf zzad(boolean z) {
        this.zzajz = (z ? 1 : 0) + (this.zzajz * zzajy);
        return this;
    }

    public final zzf zzq(Object obj) {
        this.zzajz = (obj == null ? 0 : obj.hashCode()) + (this.zzajz * zzajy);
        return this;
    }
}
