package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.safeparcel.zzb;
import com.google.android.gms.common.internal.safeparcel.zzc;

/* loaded from: classes.dex */
public final class zzasr implements Parcelable.Creator<zzasq> {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static void zza$54467ed5(zzasq zzasqVar, Parcel parcel) {
        int zzH = zzc.zzH(parcel, 20293);
        zzc.zzc(parcel, 1, zzasqVar.versionCode);
        zzc.zza$2cfb68bf(parcel, 2, zzasqVar.packageName);
        zzc.zza$2cfb68bf(parcel, 3, zzasqVar.zzbqf);
        zzc.zza$2cfb68bf(parcel, 4, zzasqVar.zzbhg);
        zzc.zza$2cfb68bf(parcel, 5, zzasqVar.zzbqg);
        zzc.zza(parcel, 6, zzasqVar.zzbqh);
        zzc.zza(parcel, 7, zzasqVar.zzbqi);
        zzc.zza$2cfb68bf(parcel, 8, zzasqVar.zzbqj);
        zzc.zza(parcel, 9, zzasqVar.zzbqk);
        zzc.zza(parcel, 10, zzasqVar.zzbql);
        zzc.zza(parcel, 11, zzasqVar.zzbqm);
        zzc.zza$2cfb68bf(parcel, 12, zzasqVar.zzbqn);
        zzc.zzI(parcel, zzH);
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ zzasq[] newArray(int i) {
        return new zzasq[i];
    }

    @Override // android.os.Parcelable.Creator
    public final /* synthetic */ zzasq createFromParcel(Parcel parcel) {
        int zzaU = zzb.zzaU(parcel);
        int i = 0;
        String str = null;
        String str2 = null;
        String str3 = null;
        String str4 = null;
        long j = 0;
        long j2 = 0;
        String str5 = null;
        boolean z = false;
        boolean z2 = false;
        long j3 = 0;
        String str6 = null;
        while (parcel.dataPosition() < zzaU) {
            int readInt = parcel.readInt();
            switch (65535 & readInt) {
                case 1:
                    i = zzb.zzg(parcel, readInt);
                    break;
                case 2:
                    str = zzb.zzq(parcel, readInt);
                    break;
                case 3:
                    str2 = zzb.zzq(parcel, readInt);
                    break;
                case 4:
                    str3 = zzb.zzq(parcel, readInt);
                    break;
                case 5:
                    str4 = zzb.zzq(parcel, readInt);
                    break;
                case 6:
                    j = zzb.zzi(parcel, readInt);
                    break;
                case 7:
                    j2 = zzb.zzi(parcel, readInt);
                    break;
                case 8:
                    str5 = zzb.zzq(parcel, readInt);
                    break;
                case 9:
                    z = zzb.zzc(parcel, readInt);
                    break;
                case 10:
                    z2 = zzb.zzc(parcel, readInt);
                    break;
                case 11:
                    j3 = zzb.zzi(parcel, readInt);
                    break;
                case 12:
                    str6 = zzb.zzq(parcel, readInt);
                    break;
                default:
                    zzb.zzb(parcel, readInt);
                    break;
            }
        }
        if (parcel.dataPosition() != zzaU) {
            throw new zzb.zza(new StringBuilder(37).append("Overread allowed size end=").append(zzaU).toString(), parcel);
        }
        return new zzasq(i, str, str2, str3, str4, j, j2, str5, z, z2, j3, str6);
    }
}
