package com.google.android.gms.common.util;

import android.os.SystemClock;

/* loaded from: classes.dex */
public final class zzh implements zze {
    private static zzh zzaGK = new zzh();

    private zzh() {
    }

    public static zze zzyv() {
        return zzaGK;
    }

    @Override // com.google.android.gms.common.util.zze
    public final long currentTimeMillis() {
        return System.currentTimeMillis();
    }

    @Override // com.google.android.gms.common.util.zze
    public final long elapsedRealtime() {
        return SystemClock.elapsedRealtime();
    }

    @Override // com.google.android.gms.common.util.zze
    public final long nanoTime() {
        return System.nanoTime();
    }
}
