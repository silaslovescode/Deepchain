package com.google.common.base;

/* loaded from: classes.dex */
public final class Objects {
    public static boolean equal(Object a, Object b) {
        return a == b || (a != null && a.equals(b));
    }

    public static ToStringHelper toStringHelper(Object self) {
        String replaceAll = self.getClass().getName().replaceAll("\\$[0-9]+", "\\$");
        int lastIndexOf = replaceAll.lastIndexOf(36);
        if (lastIndexOf == -1) {
            lastIndexOf = replaceAll.lastIndexOf(46);
        }
        return new ToStringHelper(replaceAll.substring(lastIndexOf + 1), (byte) 0);
    }

    public static <T> T firstNonNull(T first, T second) {
        return first != null ? first : (T) Preconditions.checkNotNull(second);
    }

    /* loaded from: classes.dex */
    public static final class ToStringHelper {
        private final String className;
        private ValueHolder holderHead;
        private ValueHolder holderTail;
        public boolean omitNullValues;

        /* synthetic */ ToStringHelper(String x0, byte b) {
            this(x0);
        }

        private ToStringHelper(String className) {
            this.holderHead = new ValueHolder((byte) 0);
            this.holderTail = this.holderHead;
            this.omitNullValues = false;
            this.className = (String) Preconditions.checkNotNull(className);
        }

        public final ToStringHelper add(String name, boolean value) {
            return addHolder(name, String.valueOf(value));
        }

        public final ToStringHelper add(String name, int value) {
            return addHolder(name, String.valueOf(value));
        }

        public final ToStringHelper add(String name, long value) {
            return addHolder(name, String.valueOf(value));
        }

        public final String toString() {
            boolean omitNullValuesSnapshot = this.omitNullValues;
            String nextSeparator = "";
            StringBuilder builder = new StringBuilder(32).append(this.className).append('{');
            for (ValueHolder valueHolder = this.holderHead.next; valueHolder != null; valueHolder = valueHolder.next) {
                if (!omitNullValuesSnapshot || valueHolder.value != null) {
                    builder.append(nextSeparator);
                    nextSeparator = ", ";
                    if (valueHolder.name != null) {
                        builder.append(valueHolder.name).append('=');
                    }
                    builder.append(valueHolder.value);
                }
            }
            return builder.append('}').toString();
        }

        private ValueHolder addHolder() {
            ValueHolder valueHolder = new ValueHolder((byte) 0);
            this.holderTail.next = valueHolder;
            this.holderTail = valueHolder;
            return valueHolder;
        }

        public final ToStringHelper addHolder(String name, Object value) {
            ValueHolder valueHolder = addHolder();
            valueHolder.value = value;
            valueHolder.name = (String) Preconditions.checkNotNull(name);
            return this;
        }

        /* JADX INFO: Access modifiers changed from: private */
        /* loaded from: classes.dex */
        public static final class ValueHolder {
            String name;
            ValueHolder next;
            Object value;

            private ValueHolder() {
            }

            /* synthetic */ ValueHolder(byte b) {
                this();
            }
        }

        public final ToStringHelper addValue(Object value) {
            addHolder().value = value;
            return this;
        }
    }
}
