package com.google.android.gms.flags.impl;

/* loaded from: classes.dex */
public abstract class zza<T> {

    /* renamed from: com.google.android.gms.flags.impl.zza$zza  reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public static class C0797zza extends zza<Boolean> {
    }

    /* loaded from: classes.dex */
    public static class zzb extends zza<Integer> {
    }

    /* loaded from: classes.dex */
    public static class zzc extends zza<Long> {
    }

    /* loaded from: classes.dex */
    public static class zzd extends zza<String> {
    }
}
