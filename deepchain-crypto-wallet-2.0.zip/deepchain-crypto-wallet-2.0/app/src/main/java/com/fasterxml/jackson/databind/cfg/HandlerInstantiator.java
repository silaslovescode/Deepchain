package com.fasterxml.jackson.databind.cfg;

/* loaded from: classes.dex */
public abstract class HandlerInstantiator {
}
