package com.fasterxml.jackson.databind.jsontype;

/* loaded from: classes.dex */
public abstract class SubtypeResolver {
}
