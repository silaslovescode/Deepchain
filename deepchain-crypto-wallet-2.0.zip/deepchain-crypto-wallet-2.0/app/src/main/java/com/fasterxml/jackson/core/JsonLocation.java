package com.fasterxml.jackson.core;

import java.io.Serializable;

/* loaded from: classes.dex */
public final class JsonLocation implements Serializable {

    /* renamed from: NA */
    public static final JsonLocation f20NA = new JsonLocation("N/A");
    private static final long serialVersionUID = 1;
    final transient Object _sourceRef;
    final long _totalBytes = -1;
    final long _totalChars = -1;
    final int _lineNr = -1;
    final int _columnNr = -1;

    private JsonLocation(Object sourceRef) {
        this._sourceRef = sourceRef;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder(80);
        sb.append("[Source: ");
        if (this._sourceRef == null) {
            sb.append("UNKNOWN");
        } else {
            sb.append(this._sourceRef.toString());
        }
        sb.append("; line: ");
        sb.append(this._lineNr);
        sb.append(", column: ");
        sb.append(this._columnNr);
        sb.append(']');
        return sb.toString();
    }

    public final int hashCode() {
        return ((((this._sourceRef == null ? 1 : this._sourceRef.hashCode()) ^ this._lineNr) + this._columnNr) ^ ((int) this._totalChars)) + ((int) this._totalBytes);
    }

    public final boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if (other != null && (other instanceof JsonLocation)) {
            JsonLocation otherLoc = (JsonLocation) other;
            if (this._sourceRef == null) {
                if (otherLoc._sourceRef != null) {
                    return false;
                }
            } else if (!this._sourceRef.equals(otherLoc._sourceRef)) {
                return false;
            }
            return this._lineNr == otherLoc._lineNr && this._columnNr == otherLoc._columnNr && this._totalChars == otherLoc._totalChars && this._totalBytes == otherLoc._totalBytes;
        }
        return false;
    }
}
