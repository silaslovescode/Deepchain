package com.fasterxml.jackson.databind.type;

/* loaded from: classes.dex */
public abstract class TypeModifier {
}
