package com.fasterxml.jackson.databind.ser.std;

import java.math.BigInteger;

/* loaded from: classes.dex */
public final class NumberSerializer extends StdScalarSerializer<Number> {
    public static final NumberSerializer instance = new NumberSerializer(Number.class);
    protected final boolean _isInt;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public NumberSerializer(Class<? extends Number> rawType) {
        super(rawType, (byte) 0);
        boolean z = false;
        this._isInt = rawType == BigInteger.class ? true : z;
    }
}
