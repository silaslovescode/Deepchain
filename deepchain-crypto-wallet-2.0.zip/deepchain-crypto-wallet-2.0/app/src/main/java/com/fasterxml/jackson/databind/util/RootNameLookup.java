package com.fasterxml.jackson.databind.util;

import android.support.p002v7.widget.helper.ItemTouchHelper;
import com.fasterxml.jackson.databind.PropertyName;
import com.fasterxml.jackson.databind.type.ClassKey;
import java.io.Serializable;

/* loaded from: classes.dex */
public final class RootNameLookup implements Serializable {
    private static final long serialVersionUID = 1;
    protected transient LRUMap<ClassKey, PropertyName> _rootNames = new LRUMap<>(20, ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION);

    protected final Object readResolve() {
        return new RootNameLookup();
    }
}
