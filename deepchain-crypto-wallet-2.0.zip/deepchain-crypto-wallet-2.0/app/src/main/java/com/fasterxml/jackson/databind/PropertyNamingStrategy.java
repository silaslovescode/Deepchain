package com.fasterxml.jackson.databind;

import java.io.Serializable;

/* loaded from: classes.dex */
public class PropertyNamingStrategy implements Serializable {
    public static final PropertyNamingStrategy SNAKE_CASE = new SnakeCaseStrategy();
    public static final PropertyNamingStrategy UPPER_CAMEL_CASE = new UpperCamelCaseStrategy();
    public static final PropertyNamingStrategy LOWER_CAMEL_CASE = new PropertyNamingStrategy();
    public static final PropertyNamingStrategy LOWER_CASE = new LowerCaseStrategy();
    public static final PropertyNamingStrategy KEBAB_CASE = new KebabCaseStrategy();
    @Deprecated
    public static final PropertyNamingStrategy CAMEL_CASE_TO_LOWER_CASE_WITH_UNDERSCORES = SNAKE_CASE;
    @Deprecated
    public static final PropertyNamingStrategy PASCAL_CASE_TO_CAMEL_CASE = UPPER_CAMEL_CASE;

    /* loaded from: classes.dex */
    public static class KebabCaseStrategy extends PropertyNamingStrategyBase {
    }

    /* loaded from: classes.dex */
    public static class LowerCaseStrategy extends PropertyNamingStrategyBase {
    }

    /* loaded from: classes.dex */
    public static abstract class PropertyNamingStrategyBase extends PropertyNamingStrategy {
    }

    /* loaded from: classes.dex */
    public static class SnakeCaseStrategy extends PropertyNamingStrategyBase {
    }

    /* loaded from: classes.dex */
    public static class UpperCamelCaseStrategy extends PropertyNamingStrategyBase {
    }
}
