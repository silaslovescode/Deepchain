package com.fasterxml.jackson.databind;

import java.io.Serializable;

/* loaded from: classes.dex */
public abstract class AnnotationIntrospector implements Serializable {
}
