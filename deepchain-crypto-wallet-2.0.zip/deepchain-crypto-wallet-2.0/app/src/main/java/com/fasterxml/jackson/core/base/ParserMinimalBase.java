package com.fasterxml.jackson.core.base;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;

/* loaded from: classes.dex */
public abstract class ParserMinimalBase extends JsonParser {
    protected JsonToken _currToken;

    /* JADX INFO: Access modifiers changed from: protected */
    public ParserMinimalBase() {
        super((byte) 0);
    }
}
