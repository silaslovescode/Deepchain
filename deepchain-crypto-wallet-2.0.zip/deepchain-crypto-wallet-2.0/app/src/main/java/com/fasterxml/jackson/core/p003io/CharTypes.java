package com.fasterxml.jackson.core.p003io;

import android.support.p000v4.app.NotificationCompat;
import java.util.Arrays;

/* renamed from: com.fasterxml.jackson.core.io.CharTypes */
/* loaded from: classes.dex */
public final class CharTypes {

    /* renamed from: HB */
    private static final byte[] f21HB;

    /* renamed from: HC */
    private static final char[] f22HC;
    private static final int[] sHexValues;
    private static final int[] sInputCodes;
    private static final int[] sInputCodesComment;
    private static final int[] sInputCodesJsNames;
    private static final int[] sInputCodesUTF8;
    private static final int[] sInputCodesUtf8JsNames;
    private static final int[] sInputCodesWS;
    private static final int[] sOutputEscapes128;

    static {
        int code;
        char[] charArray = "0123456789ABCDEF".toCharArray();
        f22HC = charArray;
        int len = charArray.length;
        f21HB = new byte[len];
        for (int i = 0; i < len; i++) {
            f21HB[i] = (byte) f22HC[i];
        }
        int[] table = new int[NotificationCompat.FLAG_LOCAL_ONLY];
        for (int i2 = 0; i2 < 32; i2++) {
            table[i2] = -1;
        }
        table[34] = 1;
        table[92] = 1;
        sInputCodes = table;
        int[] table2 = new int[NotificationCompat.FLAG_LOCAL_ONLY];
        System.arraycopy(sInputCodes, 0, table2, 0, NotificationCompat.FLAG_LOCAL_ONLY);
        for (int c = NotificationCompat.FLAG_HIGH_PRIORITY; c < 256; c++) {
            if ((c & 224) == 192) {
                code = 2;
            } else if ((c & 240) == 224) {
                code = 3;
            } else if ((c & 248) == 240) {
                code = 4;
            } else {
                code = -1;
            }
            table2[c] = code;
        }
        sInputCodesUTF8 = table2;
        int[] table3 = new int[NotificationCompat.FLAG_LOCAL_ONLY];
        Arrays.fill(table3, -1);
        for (int i3 = 33; i3 < 256; i3++) {
            if (Character.isJavaIdentifierPart((char) i3)) {
                table3[i3] = 0;
            }
        }
        table3[64] = 0;
        table3[35] = 0;
        table3[42] = 0;
        table3[45] = 0;
        table3[43] = 0;
        sInputCodesJsNames = table3;
        int[] table4 = new int[NotificationCompat.FLAG_LOCAL_ONLY];
        System.arraycopy(sInputCodesJsNames, 0, table4, 0, NotificationCompat.FLAG_LOCAL_ONLY);
        Arrays.fill(table4, (int) NotificationCompat.FLAG_HIGH_PRIORITY, (int) NotificationCompat.FLAG_HIGH_PRIORITY, 0);
        sInputCodesUtf8JsNames = table4;
        int[] buf = new int[NotificationCompat.FLAG_LOCAL_ONLY];
        System.arraycopy(sInputCodesUTF8, NotificationCompat.FLAG_HIGH_PRIORITY, buf, NotificationCompat.FLAG_HIGH_PRIORITY, NotificationCompat.FLAG_HIGH_PRIORITY);
        Arrays.fill(buf, 0, 32, -1);
        buf[9] = 0;
        buf[10] = 10;
        buf[13] = 13;
        buf[42] = 42;
        sInputCodesComment = buf;
        int[] buf2 = new int[NotificationCompat.FLAG_LOCAL_ONLY];
        System.arraycopy(sInputCodesUTF8, NotificationCompat.FLAG_HIGH_PRIORITY, buf2, NotificationCompat.FLAG_HIGH_PRIORITY, NotificationCompat.FLAG_HIGH_PRIORITY);
        Arrays.fill(buf2, 0, 32, -1);
        buf2[32] = 1;
        buf2[9] = 1;
        buf2[10] = 10;
        buf2[13] = 13;
        buf2[47] = 47;
        buf2[35] = 35;
        sInputCodesWS = buf2;
        int[] table5 = new int[NotificationCompat.FLAG_HIGH_PRIORITY];
        for (int i4 = 0; i4 < 32; i4++) {
            table5[i4] = -1;
        }
        table5[34] = 34;
        table5[92] = 92;
        table5[8] = 98;
        table5[9] = 116;
        table5[12] = 102;
        table5[10] = 110;
        table5[13] = 114;
        sOutputEscapes128 = table5;
        int[] iArr = new int[NotificationCompat.FLAG_HIGH_PRIORITY];
        sHexValues = iArr;
        Arrays.fill(iArr, -1);
        for (int i5 = 0; i5 < 10; i5++) {
            sHexValues[i5 + 48] = i5;
        }
        for (int i6 = 0; i6 < 6; i6++) {
            sHexValues[i6 + 97] = i6 + 10;
            sHexValues[i6 + 65] = i6 + 10;
        }
    }

    public static void appendQuoted(StringBuilder sb, String content) {
        int[] escCodes = sOutputEscapes128;
        int escLen = escCodes.length;
        int len = content.length();
        for (int i = 0; i < len; i++) {
            char c = content.charAt(i);
            if (c >= escLen || escCodes[c] == 0) {
                sb.append(c);
            } else {
                sb.append('\\');
                int escCode = escCodes[c];
                if (escCode < 0) {
                    sb.append('u');
                    sb.append('0');
                    sb.append('0');
                    sb.append(f22HC[c >> 4]);
                    sb.append(f22HC[c & 15]);
                } else {
                    sb.append((char) escCode);
                }
            }
        }
    }
}
