package com.fasterxml.jackson.databind.introspect;

import java.lang.annotation.Annotation;
import java.util.HashMap;

/* loaded from: classes.dex */
public final class AnnotationMap {
    protected HashMap<Class<?>, Annotation> _annotations;

    public final String toString() {
        return this._annotations == null ? "[null]" : this._annotations.toString();
    }
}
