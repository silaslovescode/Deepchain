package com.fasterxml.jackson.databind.cfg;

/* loaded from: classes.dex */
public interface ConfigFeature {
    boolean enabledByDefault();

    int getMask();
}
