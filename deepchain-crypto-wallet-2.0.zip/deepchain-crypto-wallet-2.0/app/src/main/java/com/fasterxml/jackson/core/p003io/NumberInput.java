package com.fasterxml.jackson.core.p003io;

/* renamed from: com.fasterxml.jackson.core.io.NumberInput */
/* loaded from: classes.dex */
public final class NumberInput {
    static final String MIN_LONG_STR_NO_SIGN = "-9223372036854775808".substring(1);
    static final String MAX_LONG_STR = "9223372036854775807";

    public static boolean inLongRange$505cbf47(String s) {
        String cmp = MAX_LONG_STR;
        int cmpLen = cmp.length();
        int alen = s.length();
        if (alen < cmpLen) {
            return true;
        }
        if (alen > cmpLen) {
            return false;
        }
        for (int i = 0; i < cmpLen; i++) {
            int diff = s.charAt(i) - cmp.charAt(i);
            if (diff != 0) {
                return diff < 0;
            }
        }
        return true;
    }
}
