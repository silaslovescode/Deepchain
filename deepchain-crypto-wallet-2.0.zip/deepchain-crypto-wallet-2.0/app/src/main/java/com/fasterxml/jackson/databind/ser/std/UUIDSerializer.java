package com.fasterxml.jackson.databind.ser.std;

import java.util.UUID;

/* loaded from: classes.dex */
public final class UUIDSerializer extends StdScalarSerializer<UUID> {
    static final char[] HEX_CHARS = "0123456789abcdef".toCharArray();

    public UUIDSerializer() {
        super(UUID.class);
    }
}
