package com.fasterxml.jackson.core;

/* loaded from: classes.dex */
public interface PrettyPrinter {
}
