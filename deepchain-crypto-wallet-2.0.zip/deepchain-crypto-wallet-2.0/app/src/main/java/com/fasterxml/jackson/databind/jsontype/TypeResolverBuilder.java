package com.fasterxml.jackson.databind.jsontype;

import com.fasterxml.jackson.databind.jsontype.TypeResolverBuilder;

/* loaded from: classes.dex */
public interface TypeResolverBuilder<T extends TypeResolverBuilder<T>> {
}
