package com.fasterxml.jackson.databind;

import java.io.Serializable;

/* loaded from: classes.dex */
public final class PropertyName implements Serializable {
    private static final long serialVersionUID = 1;
    protected final String _namespace;
    protected final String _simpleName;
    public static final PropertyName USE_DEFAULT = new PropertyName("", (byte) 0);
    public static final PropertyName NO_NAME = new PropertyName(new String(""), (byte) 0);

    public PropertyName(String simpleName) {
        this(simpleName, (byte) 0);
    }

    private PropertyName(String simpleName, byte b) {
        this._simpleName = simpleName == null ? "" : simpleName;
        this._namespace = null;
    }

    protected final Object readResolve() {
        if (this._simpleName == null || "".equals(this._simpleName)) {
            return USE_DEFAULT;
        }
        if (this._simpleName.equals("") && this._namespace == null) {
            return NO_NAME;
        }
        return this;
    }

    public final boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (o != null && o.getClass() == getClass()) {
            PropertyName other = (PropertyName) o;
            if (this._simpleName == null) {
                if (other._simpleName != null) {
                    return false;
                }
            } else if (!this._simpleName.equals(other._simpleName)) {
                return false;
            }
            if (this._namespace != null) {
                return this._namespace.equals(other._namespace);
            }
            return other._namespace == null;
        }
        return false;
    }

    public final int hashCode() {
        return this._namespace == null ? this._simpleName.hashCode() : this._namespace.hashCode() ^ this._simpleName.hashCode();
    }

    public final String toString() {
        return this._namespace == null ? this._simpleName : "{" + this._namespace + "}" + this._simpleName;
    }
}
