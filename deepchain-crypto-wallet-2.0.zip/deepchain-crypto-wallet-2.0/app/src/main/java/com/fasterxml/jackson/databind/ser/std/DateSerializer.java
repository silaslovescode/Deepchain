package com.fasterxml.jackson.databind.ser.std;

import java.util.Date;

/* loaded from: classes.dex */
public final class DateSerializer extends DateTimeSerializerBase<Date> {
    public static final DateSerializer instance = new DateSerializer();

    public DateSerializer() {
        this((byte) 0);
    }

    private DateSerializer(byte b) {
        super(Date.class, null);
    }
}
