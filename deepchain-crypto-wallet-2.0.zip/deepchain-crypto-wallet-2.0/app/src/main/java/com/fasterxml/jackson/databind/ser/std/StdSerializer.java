package com.fasterxml.jackson.databind.ser.std;

import com.fasterxml.jackson.databind.JsonSerializer;
import java.io.Serializable;

/* loaded from: classes.dex */
public abstract class StdSerializer<T> extends JsonSerializer<T> implements Serializable {
    private static final Object CONVERTING_CONTENT_CONVERTER_LOCK = new Object();
    private static final long serialVersionUID = 1;
    protected final Class<T> _handledType;

    /* JADX INFO: Access modifiers changed from: protected */
    public StdSerializer(Class<T> t) {
        this._handledType = t;
    }
}
