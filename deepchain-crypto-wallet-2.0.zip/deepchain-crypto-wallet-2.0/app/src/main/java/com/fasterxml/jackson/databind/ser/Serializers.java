package com.fasterxml.jackson.databind.ser;

/* loaded from: classes.dex */
public interface Serializers {
}
