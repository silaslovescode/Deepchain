package com.fasterxml.jackson.databind.ser;

/* loaded from: classes.dex */
public abstract class FilterProvider {
}
