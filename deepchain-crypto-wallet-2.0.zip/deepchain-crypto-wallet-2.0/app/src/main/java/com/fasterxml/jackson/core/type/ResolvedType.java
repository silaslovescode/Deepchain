package com.fasterxml.jackson.core.type;

/* loaded from: classes.dex */
public abstract class ResolvedType {
    public abstract String toCanonical();
}
