package com.fasterxml.jackson.databind;

/* loaded from: classes.dex */
public abstract class DatabindContext {
}
