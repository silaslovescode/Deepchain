package com.fasterxml.jackson.databind.introspect;

/* loaded from: classes.dex */
public final class POJOPropertiesCollector {
}
