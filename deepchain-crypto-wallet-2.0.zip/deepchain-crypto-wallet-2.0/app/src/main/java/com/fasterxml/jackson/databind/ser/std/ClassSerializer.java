package com.fasterxml.jackson.databind.ser.std;

/* loaded from: classes.dex */
public class ClassSerializer extends StdScalarSerializer<Class<?>> {
    public ClassSerializer() {
        super(Class.class, (byte) 0);
    }
}
