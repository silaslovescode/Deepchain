package com.fasterxml.jackson.core.p003io;

import java.io.Serializable;

/* renamed from: com.fasterxml.jackson.core.io.OutputDecorator */
/* loaded from: classes.dex */
public abstract class OutputDecorator implements Serializable {
}
