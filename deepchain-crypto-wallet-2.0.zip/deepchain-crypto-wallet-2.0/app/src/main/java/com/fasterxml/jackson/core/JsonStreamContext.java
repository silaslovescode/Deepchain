package com.fasterxml.jackson.core;

/* loaded from: classes.dex */
public abstract class JsonStreamContext {
    protected int _index;
    protected int _type;

    public final int getCurrentIndex() {
        if (this._index < 0) {
            return 0;
        }
        return this._index;
    }
}
