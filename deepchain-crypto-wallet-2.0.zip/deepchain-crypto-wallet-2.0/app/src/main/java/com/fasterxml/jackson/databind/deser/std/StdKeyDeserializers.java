package com.fasterxml.jackson.databind.deser.std;

import com.fasterxml.jackson.databind.deser.KeyDeserializers;
import java.io.Serializable;

/* loaded from: classes.dex */
public final class StdKeyDeserializers implements KeyDeserializers, Serializable {
    private static final long serialVersionUID = 1;
}
