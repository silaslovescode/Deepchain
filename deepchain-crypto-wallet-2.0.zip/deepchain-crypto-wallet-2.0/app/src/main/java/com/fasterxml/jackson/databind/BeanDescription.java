package com.fasterxml.jackson.databind;

/* loaded from: classes.dex */
public abstract class BeanDescription {
    protected final JavaType _type;

    /* JADX INFO: Access modifiers changed from: protected */
    public BeanDescription(JavaType type) {
        this._type = type;
    }
}
