package com.fasterxml.jackson.databind;

/* loaded from: classes.dex */
public interface JsonSerializable {

    /* loaded from: classes.dex */
    public static abstract class Base implements JsonSerializable {
    }
}
