package com.fasterxml.jackson.databind;

import com.fasterxml.jackson.core.type.ResolvedType;
import java.io.Serializable;
import java.lang.reflect.Type;

/* loaded from: classes.dex */
public abstract class JavaType extends ResolvedType implements Serializable, Type {
    private static final long serialVersionUID = 1;
    protected final Class<?> _class;
    protected final int _hash;
    protected final Object _valueHandler = null;
    protected final Object _typeHandler = null;
    protected final boolean _asStatic = false;

    public abstract boolean equals(Object obj);

    public abstract StringBuilder getGenericSignature(StringBuilder sb);

    /* JADX INFO: Access modifiers changed from: protected */
    public JavaType(Class<?> raw) {
        this._class = raw;
        this._hash = raw.getName().hashCode() + 0;
    }

    public final int hashCode() {
        return this._hash;
    }
}
