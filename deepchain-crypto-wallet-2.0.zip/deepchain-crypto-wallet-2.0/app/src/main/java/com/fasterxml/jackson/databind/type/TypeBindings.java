package com.fasterxml.jackson.databind.type;

import com.fasterxml.jackson.databind.JavaType;
import java.io.Serializable;

/* loaded from: classes.dex */
public final class TypeBindings implements Serializable {
    private static final long serialVersionUID = 1;
    private final int _hashCode;
    private final String[] _names;
    final JavaType[] _types;
    private final String[] _unboundVariables;
    private static final String[] NO_STRINGS = new String[0];
    private static final JavaType[] NO_TYPES = new JavaType[0];
    private static final TypeBindings EMPTY = new TypeBindings(NO_STRINGS, NO_TYPES);

    private TypeBindings(String[] names, JavaType[] types) {
        this._names = names == null ? NO_STRINGS : names;
        this._types = types == null ? NO_TYPES : types;
        if (this._names.length != this._types.length) {
            throw new IllegalArgumentException("Mismatching names (" + this._names.length + "), types (" + this._types.length + ")");
        }
        int h = 1;
        int len = this._types.length;
        for (int i = 0; i < len; i++) {
            h += this._types[i].hashCode();
        }
        this._unboundVariables = null;
        this._hashCode = h;
    }

    public static TypeBindings emptyBindings() {
        return EMPTY;
    }

    protected final Object readResolve() {
        if (this._names == null || this._names.length == 0) {
            return EMPTY;
        }
        return this;
    }

    public final String toString() {
        if (this._types.length == 0) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        sb.append('<');
        int len = this._types.length;
        for (int i = 0; i < len; i++) {
            if (i > 0) {
                sb.append(',');
            }
            JavaType javaType = this._types[i];
            StringBuilder sb2 = new StringBuilder(40);
            javaType.getGenericSignature(sb2);
            String sig = sb2.toString();
            sb.append(sig);
        }
        sb.append('>');
        return sb.toString();
    }

    public final int hashCode() {
        return this._hashCode;
    }

    public final boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (o == null || o.getClass() != getClass()) {
            return false;
        }
        TypeBindings other = (TypeBindings) o;
        int len = this._types.length;
        if (len != other._types.length) {
            return false;
        }
        JavaType[] otherTypes = other._types;
        for (int i = 0; i < len; i++) {
            if (!otherTypes[i].equals(this._types[i])) {
                return false;
            }
        }
        return true;
    }
}
