package com.fasterxml.jackson.core.sym;

import android.support.p000v4.app.NotificationCompat;
import java.util.concurrent.atomic.AtomicReference;

/* loaded from: classes.dex */
public final class ByteQuadsCanonicalizer {
    protected int _count;
    protected int[] _hashArea;
    protected int _hashSize;
    protected int _secondaryStart;
    private final int _seed;
    protected int _spilloverEnd;
    protected int _tertiaryStart;
    protected final ByteQuadsCanonicalizer _parent = null;
    protected boolean _intern = true;
    protected final boolean _failOnDoS = true;
    protected final AtomicReference<TableInfo> _tableInfo = new AtomicReference<>(new TableInfo(new int[NotificationCompat.FLAG_GROUP_SUMMARY], new String[NotificationCompat.FLAG_HIGH_PRIORITY]));

    private ByteQuadsCanonicalizer(int seed) {
        this._seed = seed;
    }

    public static ByteQuadsCanonicalizer createRoot() {
        long now = System.currentTimeMillis();
        int seed = (((int) now) + ((int) (now >>> 32))) | 1;
        return new ByteQuadsCanonicalizer(seed);
    }

    /* loaded from: classes.dex */
    private static final class TableInfo {
        public final int[] mainHash;
        public final String[] names;
        public final int size = 64;
        public final int count = 0;
        public final int tertiaryShift = 4;
        public final int spilloverEnd = 448;
        public final int longNameOffset = NotificationCompat.FLAG_GROUP_SUMMARY;

        public TableInfo(int[] mainHash, String[] names) {
            this.mainHash = mainHash;
            this.names = names;
        }
    }

    public final String toString() {
        int i = this._secondaryStart;
        int pri = 0;
        for (int i2 = 3; i2 < i; i2 += 4) {
            if (this._hashArea[i2] != 0) {
                pri++;
            }
        }
        int i3 = this._tertiaryStart;
        int sec = 0;
        for (int i4 = this._secondaryStart + 3; i4 < i3; i4 += 4) {
            if (this._hashArea[i4] != 0) {
                sec++;
            }
        }
        int i5 = this._tertiaryStart + 3;
        int i6 = this._hashSize + i5;
        int tert = 0;
        while (i5 < i6) {
            if (this._hashArea[i5] != 0) {
                tert++;
            }
            i5 += 4;
        }
        int i7 = this._spilloverEnd;
        int i8 = this._hashSize;
        int spill = (i7 - ((i8 << 3) - i8)) >> 2;
        int i9 = this._hashSize << 3;
        int total = 0;
        for (int i10 = 3; i10 < i9; i10 += 4) {
            if (this._hashArea[i10] != 0) {
                total++;
            }
        }
        return String.format("[%s: size=%d, hashSize=%d, %d/%d/%d/%d pri/sec/ter/spill (=%s), total:%d]", getClass().getName(), Integer.valueOf(this._count), Integer.valueOf(this._hashSize), Integer.valueOf(pri), Integer.valueOf(sec), Integer.valueOf(tert), Integer.valueOf(spill), Integer.valueOf(total), Integer.valueOf(pri + sec + tert + spill), Integer.valueOf(total));
    }
}
