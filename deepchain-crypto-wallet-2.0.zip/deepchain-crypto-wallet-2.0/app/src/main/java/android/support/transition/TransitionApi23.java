package android.support.transition;

import android.annotation.TargetApi;

@TargetApi(23)
/* loaded from: classes.dex */
final class TransitionApi23 extends TransitionKitKat {
}
