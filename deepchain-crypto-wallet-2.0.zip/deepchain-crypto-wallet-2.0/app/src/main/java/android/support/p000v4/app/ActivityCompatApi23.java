package android.support.p000v4.app;

import android.annotation.TargetApi;
import android.app.SharedElementCallback;
import android.content.Context;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.os.Parcelable;
import android.support.p000v4.app.ActivityCompatApi21;
import android.view.View;
import java.util.List;
import java.util.Map;

@TargetApi(23)
/* renamed from: android.support.v4.app.ActivityCompatApi23 */
/* loaded from: classes.dex */
final class ActivityCompatApi23 {

    /* renamed from: android.support.v4.app.ActivityCompatApi23$OnSharedElementsReadyListenerBridge */
    /* loaded from: classes.dex */
    public interface OnSharedElementsReadyListenerBridge {
        void onSharedElementsReady();
    }

    /* renamed from: android.support.v4.app.ActivityCompatApi23$RequestPermissionsRequestCodeValidator */
    /* loaded from: classes.dex */
    public interface RequestPermissionsRequestCodeValidator {
        void validateRequestPermissionsRequestCode(int i);
    }

    /* renamed from: android.support.v4.app.ActivityCompatApi23$SharedElementCallback23 */
    /* loaded from: classes.dex */
    public static abstract class SharedElementCallback23 extends ActivityCompatApi21.SharedElementCallback21 {
        public abstract void onSharedElementsArrived$337b2406(OnSharedElementsReadyListenerBridge onSharedElementsReadyListenerBridge);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public static SharedElementCallback createCallback(SharedElementCallback23 callback) {
        if (callback == null) {
            return null;
        }
        SharedElementCallback newListener = new SharedElementCallbackImpl(callback);
        return newListener;
    }

    /* renamed from: android.support.v4.app.ActivityCompatApi23$SharedElementCallbackImpl */
    /* loaded from: classes.dex */
    private static class SharedElementCallbackImpl extends SharedElementCallback {
        private SharedElementCallback23 mCallback;

        public SharedElementCallbackImpl(SharedElementCallback23 callback) {
            this.mCallback = callback;
        }

        @Override // android.app.SharedElementCallback
        public final void onSharedElementStart(List<String> sharedElementNames, List<View> sharedElements, List<View> sharedElementSnapshots) {
        }

        @Override // android.app.SharedElementCallback
        public final void onSharedElementEnd(List<String> sharedElementNames, List<View> sharedElements, List<View> sharedElementSnapshots) {
        }

        @Override // android.app.SharedElementCallback
        public final void onRejectSharedElements(List<View> rejectedSharedElements) {
        }

        @Override // android.app.SharedElementCallback
        public final void onMapSharedElements(List<String> names, Map<String, View> sharedElements) {
        }

        @Override // android.app.SharedElementCallback
        public final Parcelable onCaptureSharedElementSnapshot(View sharedElement, Matrix viewToGlobalMatrix, RectF screenBounds) {
            return this.mCallback.onCaptureSharedElementSnapshot(sharedElement, viewToGlobalMatrix, screenBounds);
        }

        @Override // android.app.SharedElementCallback
        public final View onCreateSnapshotView(Context context, Parcelable snapshot) {
            return this.mCallback.onCreateSnapshotView(context, snapshot);
        }

        @Override // android.app.SharedElementCallback
        public final void onSharedElementsArrived(List<String> sharedElementNames, List<View> sharedElements, final SharedElementCallback.OnSharedElementsReadyListener listener) {
            this.mCallback.onSharedElementsArrived$337b2406(new OnSharedElementsReadyListenerBridge() { // from class: android.support.v4.app.ActivityCompatApi23.SharedElementCallbackImpl.1
                @Override // android.support.p000v4.app.ActivityCompatApi23.OnSharedElementsReadyListenerBridge
                public final void onSharedElementsReady() {
                    listener.onSharedElementsReady();
                }
            });
        }
    }
}
