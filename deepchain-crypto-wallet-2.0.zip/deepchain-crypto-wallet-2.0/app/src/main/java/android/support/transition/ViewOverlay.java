package android.support.transition;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.support.p000v4.view.ViewCompat;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import java.lang.reflect.Method;
import java.util.ArrayList;

/* JADX INFO: Access modifiers changed from: package-private */
@TargetApi(14)
/* loaded from: classes.dex */
public class ViewOverlay {
    protected OverlayViewGroup mOverlayViewGroup;

    /* JADX INFO: Access modifiers changed from: package-private */
    public ViewOverlay(Context context, ViewGroup hostView, View requestingView) {
        this.mOverlayViewGroup = new OverlayViewGroup(context, hostView, requestingView, this);
    }

    public static ViewOverlay createFrom(View view) {
        ViewGroup contentView;
        View view2 = view;
        while (true) {
            if (view2 == null) {
                contentView = null;
                break;
            } else if (view2.getId() == 16908290 && (view2 instanceof ViewGroup)) {
                contentView = (ViewGroup) view2;
                break;
            } else if (view2.getParent() instanceof ViewGroup) {
                view2 = (ViewGroup) view2.getParent();
            }
        }
        if (contentView != null) {
            int numChildren = contentView.getChildCount();
            for (int i = 0; i < numChildren; i++) {
                View child = contentView.getChildAt(i);
                if (child instanceof OverlayViewGroup) {
                    return ((OverlayViewGroup) child).mViewOverlay;
                }
            }
            return new ViewGroupOverlay(contentView.getContext(), contentView, view);
        }
        return null;
    }

    public final void add(Drawable drawable) {
        OverlayViewGroup overlayViewGroup = this.mOverlayViewGroup;
        if (overlayViewGroup.mDrawables == null) {
            overlayViewGroup.mDrawables = new ArrayList<>();
        }
        if (overlayViewGroup.mDrawables.contains(drawable)) {
            return;
        }
        overlayViewGroup.mDrawables.add(drawable);
        overlayViewGroup.invalidate(drawable.getBounds());
        drawable.setCallback(overlayViewGroup);
    }

    public final void remove(Drawable drawable) {
        OverlayViewGroup overlayViewGroup = this.mOverlayViewGroup;
        if (overlayViewGroup.mDrawables == null) {
            return;
        }
        overlayViewGroup.mDrawables.remove(drawable);
        overlayViewGroup.invalidate(drawable.getBounds());
        drawable.setCallback(null);
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* loaded from: classes.dex */
    public static class OverlayViewGroup extends ViewGroup {
        static Method sInvalidateChildInParentFastMethod;
        ArrayList<Drawable> mDrawables;
        ViewGroup mHostView;
        View mRequestingView;
        ViewOverlay mViewOverlay;

        static {
            try {
                sInvalidateChildInParentFastMethod = ViewGroup.class.getDeclaredMethod("invalidateChildInParentFast", Integer.TYPE, Integer.TYPE, Rect.class);
            } catch (NoSuchMethodException e) {
            }
        }

        OverlayViewGroup(Context context, ViewGroup hostView, View requestingView, ViewOverlay viewOverlay) {
            super(context);
            this.mDrawables = null;
            this.mHostView = hostView;
            this.mRequestingView = requestingView;
            setRight(hostView.getWidth());
            setBottom(hostView.getHeight());
            hostView.addView(this);
            this.mViewOverlay = viewOverlay;
        }

        @Override // android.view.ViewGroup, android.view.View
        public final boolean dispatchTouchEvent(MotionEvent ev) {
            return false;
        }

        @Override // android.view.View
        protected final boolean verifyDrawable(Drawable who) {
            return super.verifyDrawable(who) || (this.mDrawables != null && this.mDrawables.contains(who));
        }

        public final void add(View child) {
            if (child.getParent() instanceof ViewGroup) {
                ViewGroup parent = (ViewGroup) child.getParent();
                if (parent != this.mHostView && parent.getParent() != null) {
                    int[] parentLocation = new int[2];
                    int[] hostViewLocation = new int[2];
                    parent.getLocationOnScreen(parentLocation);
                    this.mHostView.getLocationOnScreen(hostViewLocation);
                    ViewCompat.offsetLeftAndRight(child, parentLocation[0] - hostViewLocation[0]);
                    ViewCompat.offsetTopAndBottom(child, parentLocation[1] - hostViewLocation[1]);
                }
                parent.removeView(child);
                if (child.getParent() != null) {
                    parent.removeView(child);
                }
            }
            super.addView(child, getChildCount() - 1);
        }

        public final void remove(View view) {
            boolean z;
            super.removeView(view);
            if (getChildCount() == 0 && (this.mDrawables == null || this.mDrawables.size() == 0)) {
                z = true;
            } else {
                z = false;
            }
            if (z) {
                this.mHostView.removeView(this);
            }
        }

        @Override // android.view.View, android.graphics.drawable.Drawable.Callback
        public final void invalidateDrawable(Drawable drawable) {
            invalidate(drawable.getBounds());
        }

        @Override // android.view.ViewGroup, android.view.View
        protected final void dispatchDraw(Canvas canvas) {
            int numDrawables = 0;
            int[] contentViewLocation = new int[2];
            int[] hostViewLocation = new int[2];
            getParent();
            this.mHostView.getLocationOnScreen(contentViewLocation);
            this.mRequestingView.getLocationOnScreen(hostViewLocation);
            canvas.translate(hostViewLocation[0] - contentViewLocation[0], hostViewLocation[1] - contentViewLocation[1]);
            canvas.clipRect(new Rect(0, 0, this.mRequestingView.getWidth(), this.mRequestingView.getHeight()));
            super.dispatchDraw(canvas);
            if (this.mDrawables != null) {
                numDrawables = this.mDrawables.size();
            }
            for (int i = 0; i < numDrawables; i++) {
                this.mDrawables.get(i).draw(canvas);
            }
        }

        @Override // android.view.ViewGroup, android.view.View
        protected final void onLayout(boolean changed, int l, int t, int r, int b) {
        }

        @Override // android.view.ViewGroup, android.view.ViewParent
        public final ViewParent invalidateChildInParent(int[] location, Rect dirty) {
            if (this.mHostView != null) {
                dirty.offset(location[0], location[1]);
                if (this.mHostView instanceof ViewGroup) {
                    location[0] = 0;
                    location[1] = 0;
                    int[] iArr = new int[2];
                    int[] iArr2 = new int[2];
                    getParent();
                    this.mHostView.getLocationOnScreen(iArr);
                    this.mRequestingView.getLocationOnScreen(iArr2);
                    int[] offset = {iArr2[0] - iArr[0], iArr2[1] - iArr[1]};
                    dirty.offset(offset[0], offset[1]);
                    return super.invalidateChildInParent(location, dirty);
                }
                invalidate(dirty);
            }
            return null;
        }
    }
}
