package android.support.transition;

import android.animation.Animator;
import android.animation.TimeInterpolator;
import android.view.ViewGroup;

/* loaded from: classes.dex */
public abstract class TransitionImpl {
    public abstract void captureEndValues(TransitionValues transitionValues);

    public abstract void captureStartValues(TransitionValues transitionValues);

    public abstract Animator createAnimator(ViewGroup viewGroup, TransitionValues transitionValues, TransitionValues transitionValues2);

    public abstract void init(TransitionInterface transitionInterface, Object obj);

    public abstract TransitionImpl setDuration$1a9ae18f();

    public abstract TransitionImpl setInterpolator(TimeInterpolator timeInterpolator);
}
