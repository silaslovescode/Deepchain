package android.support.p000v4.content;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Process;
import android.support.p000v4.p001os.BuildCompat;
import android.util.TypedValue;
import java.io.File;

/* renamed from: android.support.v4.content.ContextCompat */
/* loaded from: classes.dex */
public class ContextCompat {
    private static final Object sLock = new Object();
    private static TypedValue sTempValue;

    public static boolean startActivities$5b3ef247(Context context, Intent[] intents) {
        int version = Build.VERSION.SDK_INT;
        if (version < 16) {
            if (version < 11) {
                return false;
            }
            context.startActivities(intents);
            return true;
        }
        context.startActivities(intents, null);
        return true;
    }

    public static File[] getExternalFilesDirs$49c295f9(Context context) {
        return Build.VERSION.SDK_INT >= 19 ? context.getExternalFilesDirs(null) : new File[]{context.getExternalFilesDir(null)};
    }

    public static File[] getExternalCacheDirs(Context context) {
        return Build.VERSION.SDK_INT >= 19 ? context.getExternalCacheDirs() : new File[]{context.getExternalCacheDir()};
    }

    public static final Drawable getDrawable(Context context, int id) {
        int resolvedId;
        int version = Build.VERSION.SDK_INT;
        if (version < 21) {
            if (version >= 16) {
                return context.getResources().getDrawable(id);
            }
            synchronized (sLock) {
                if (sTempValue == null) {
                    sTempValue = new TypedValue();
                }
                context.getResources().getValue(id, sTempValue, true);
                resolvedId = sTempValue.resourceId;
            }
            return context.getResources().getDrawable(resolvedId);
        }
        return context.getDrawable(id);
    }

    public static final ColorStateList getColorStateList(Context context, int id) {
        return Build.VERSION.SDK_INT >= 23 ? context.getColorStateList(id) : context.getResources().getColorStateList(id);
    }

    public static final int getColor(Context context, int id) {
        return Build.VERSION.SDK_INT >= 23 ? context.getColor(id) : context.getResources().getColor(id);
    }

    public static int checkSelfPermission(Context context, String permission) {
        return context.checkPermission(permission, Process.myPid(), Process.myUid());
    }

    public static Context createDeviceProtectedStorageContext(Context context) {
        if (BuildCompat.isAtLeastN()) {
            return context.createDeviceProtectedStorageContext();
        }
        return null;
    }

    public static boolean isDeviceProtectedStorage(Context context) {
        if (BuildCompat.isAtLeastN()) {
            return context.isDeviceProtectedStorage();
        }
        return false;
    }
}
