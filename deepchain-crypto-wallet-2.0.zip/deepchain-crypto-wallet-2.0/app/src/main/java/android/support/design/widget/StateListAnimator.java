package android.support.design.widget;

import android.support.design.widget.ValueAnimatorCompat;
import java.util.ArrayList;

/* loaded from: classes.dex */
final class StateListAnimator {
    final ArrayList<Tuple> mTuples = new ArrayList<>();
    Tuple mLastMatch = null;
    ValueAnimatorCompat mRunningAnimator = null;
    private final ValueAnimatorCompat.AnimatorListener mAnimationListener = new ValueAnimatorCompat.AnimatorListenerAdapter() { // from class: android.support.design.widget.StateListAnimator.1
        @Override // android.support.design.widget.ValueAnimatorCompat.AnimatorListenerAdapter, android.support.design.widget.ValueAnimatorCompat.AnimatorListener
        public final void onAnimationEnd(ValueAnimatorCompat animator) {
            if (StateListAnimator.this.mRunningAnimator == animator) {
                StateListAnimator.this.mRunningAnimator = null;
            }
        }
    };

    public final void addState(int[] specs, ValueAnimatorCompat animator) {
        Tuple tuple = new Tuple(specs, animator);
        animator.addListener(this.mAnimationListener);
        this.mTuples.add(tuple);
    }

    /* loaded from: classes.dex */
    static class Tuple {
        final ValueAnimatorCompat mAnimator;
        final int[] mSpecs;

        Tuple(int[] specs, ValueAnimatorCompat animator) {
            this.mSpecs = specs;
            this.mAnimator = animator;
        }
    }
}
