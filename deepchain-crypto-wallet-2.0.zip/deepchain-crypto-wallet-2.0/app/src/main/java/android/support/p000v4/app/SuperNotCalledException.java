package android.support.p000v4.app;

import android.util.AndroidRuntimeException;

/* renamed from: android.support.v4.app.SuperNotCalledException */
/* loaded from: classes.dex */
final class SuperNotCalledException extends AndroidRuntimeException {
    public SuperNotCalledException(String msg) {
        super(msg);
    }
}
