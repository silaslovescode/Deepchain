package android.support.p000v4.app;

import android.annotation.TargetApi;
import android.os.Bundle;
import android.support.p000v4.app.RemoteInputCompatBase;

@TargetApi(16)
/* renamed from: android.support.v4.app.RemoteInputCompatJellybean */
/* loaded from: classes.dex */
final class RemoteInputCompatJellybean {
    /* JADX INFO: Access modifiers changed from: package-private */
    public static Bundle[] toBundleArray(RemoteInputCompatBase.RemoteInput[] remoteInputs) {
        if (remoteInputs == null) {
            return null;
        }
        Bundle[] bundles = new Bundle[remoteInputs.length];
        for (int i = 0; i < remoteInputs.length; i++) {
            RemoteInputCompatBase.RemoteInput remoteInput = remoteInputs[i];
            Bundle bundle = new Bundle();
            bundle.putString("resultKey", remoteInput.getResultKey());
            bundle.putCharSequence("label", remoteInput.getLabel());
            bundle.putCharSequenceArray("choices", remoteInput.getChoices());
            bundle.putBoolean("allowFreeFormInput", remoteInput.getAllowFreeFormInput());
            bundle.putBundle("extras", remoteInput.getExtras());
            bundles[i] = bundle;
        }
        return bundles;
    }
}
