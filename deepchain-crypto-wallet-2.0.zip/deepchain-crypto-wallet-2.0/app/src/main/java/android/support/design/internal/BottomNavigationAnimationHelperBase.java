package android.support.design.internal;

import android.view.ViewGroup;

/* JADX INFO: Access modifiers changed from: package-private */
/* loaded from: classes.dex */
public class BottomNavigationAnimationHelperBase {
    /* JADX INFO: Access modifiers changed from: package-private */
    public void beginDelayedTransition(ViewGroup view) {
    }
}
