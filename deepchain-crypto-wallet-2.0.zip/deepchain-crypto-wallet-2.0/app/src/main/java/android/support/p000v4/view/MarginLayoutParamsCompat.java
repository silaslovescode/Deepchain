package android.support.p000v4.view;

import android.os.Build;
import android.view.ViewGroup;

/* renamed from: android.support.v4.view.MarginLayoutParamsCompat */
/* loaded from: classes.dex */
public final class MarginLayoutParamsCompat {
    static final MarginLayoutParamsCompatImpl IMPL;

    /* renamed from: android.support.v4.view.MarginLayoutParamsCompat$MarginLayoutParamsCompatImpl */
    /* loaded from: classes.dex */
    interface MarginLayoutParamsCompatImpl {
        int getMarginEnd(ViewGroup.MarginLayoutParams marginLayoutParams);

        int getMarginStart(ViewGroup.MarginLayoutParams marginLayoutParams);
    }

    /* renamed from: android.support.v4.view.MarginLayoutParamsCompat$MarginLayoutParamsCompatImplBase */
    /* loaded from: classes.dex */
    static class MarginLayoutParamsCompatImplBase implements MarginLayoutParamsCompatImpl {
        MarginLayoutParamsCompatImplBase() {
        }

        @Override // android.support.p000v4.view.MarginLayoutParamsCompat.MarginLayoutParamsCompatImpl
        public final int getMarginStart(ViewGroup.MarginLayoutParams lp) {
            return lp.leftMargin;
        }

        @Override // android.support.p000v4.view.MarginLayoutParamsCompat.MarginLayoutParamsCompatImpl
        public final int getMarginEnd(ViewGroup.MarginLayoutParams lp) {
            return lp.rightMargin;
        }
    }

    /* renamed from: android.support.v4.view.MarginLayoutParamsCompat$MarginLayoutParamsCompatImplJbMr1 */
    /* loaded from: classes.dex */
    static class MarginLayoutParamsCompatImplJbMr1 implements MarginLayoutParamsCompatImpl {
        MarginLayoutParamsCompatImplJbMr1() {
        }

        @Override // android.support.p000v4.view.MarginLayoutParamsCompat.MarginLayoutParamsCompatImpl
        public final int getMarginStart(ViewGroup.MarginLayoutParams lp) {
            return lp.getMarginStart();
        }

        @Override // android.support.p000v4.view.MarginLayoutParamsCompat.MarginLayoutParamsCompatImpl
        public final int getMarginEnd(ViewGroup.MarginLayoutParams lp) {
            return lp.getMarginEnd();
        }
    }

    static {
        if (Build.VERSION.SDK_INT >= 17) {
            IMPL = new MarginLayoutParamsCompatImplJbMr1();
        } else {
            IMPL = new MarginLayoutParamsCompatImplBase();
        }
    }

    public static int getMarginStart(ViewGroup.MarginLayoutParams lp) {
        return IMPL.getMarginStart(lp);
    }

    public static int getMarginEnd(ViewGroup.MarginLayoutParams lp) {
        return IMPL.getMarginEnd(lp);
    }
}
