package android.support.p002v7.view;

/* renamed from: android.support.v7.view.CollapsibleActionView */
/* loaded from: classes.dex */
public interface CollapsibleActionView {
    void onActionViewCollapsed();

    void onActionViewExpanded();
}
