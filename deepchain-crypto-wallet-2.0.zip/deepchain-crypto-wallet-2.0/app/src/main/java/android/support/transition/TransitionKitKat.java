package android.support.transition;

import android.animation.Animator;
import android.animation.TimeInterpolator;
import android.annotation.TargetApi;
import android.view.ViewGroup;

@TargetApi(19)
/* loaded from: classes.dex */
class TransitionKitKat extends TransitionImpl {
    TransitionInterface mExternalTransition;
    android.transition.Transition mTransition;

    static void copyValues(android.transition.TransitionValues source, TransitionValues dest) {
        if (source != null) {
            dest.view = source.view;
            if (source.values.size() > 0) {
                dest.values.putAll(source.values);
            }
        }
    }

    static void copyValues(TransitionValues source, android.transition.TransitionValues dest) {
        if (source != null) {
            dest.view = source.view;
            if (source.values.size() > 0) {
                dest.values.putAll(source.values);
            }
        }
    }

    static TransitionValues convertToSupport(android.transition.TransitionValues values) {
        if (values == null) {
            return null;
        }
        TransitionValues supportValues = new TransitionValues();
        copyValues(values, supportValues);
        return supportValues;
    }

    @Override // android.support.transition.TransitionImpl
    public final void init(TransitionInterface external, Object internal) {
        this.mExternalTransition = external;
        if (internal == null) {
            this.mTransition = new TransitionWrapper(external);
        } else {
            this.mTransition = (android.transition.Transition) internal;
        }
    }

    @Override // android.support.transition.TransitionImpl
    public final void captureEndValues(TransitionValues transitionValues) {
        android.transition.TransitionValues internalValues = new android.transition.TransitionValues();
        copyValues(transitionValues, internalValues);
        this.mTransition.captureEndValues(internalValues);
        copyValues(internalValues, transitionValues);
    }

    @Override // android.support.transition.TransitionImpl
    public final void captureStartValues(TransitionValues transitionValues) {
        android.transition.TransitionValues internalValues = new android.transition.TransitionValues();
        copyValues(transitionValues, internalValues);
        this.mTransition.captureStartValues(internalValues);
        copyValues(internalValues, transitionValues);
    }

    @Override // android.support.transition.TransitionImpl
    public final Animator createAnimator(ViewGroup sceneRoot, TransitionValues startValues, TransitionValues endValues) {
        android.transition.TransitionValues internalStartValues;
        android.transition.TransitionValues internalEndValues;
        if (startValues != null) {
            internalStartValues = new android.transition.TransitionValues();
            copyValues(startValues, internalStartValues);
        } else {
            internalStartValues = null;
        }
        if (endValues != null) {
            internalEndValues = new android.transition.TransitionValues();
            copyValues(endValues, internalEndValues);
        } else {
            internalEndValues = null;
        }
        return this.mTransition.createAnimator(sceneRoot, internalStartValues, internalEndValues);
    }

    @Override // android.support.transition.TransitionImpl
    public final TransitionImpl setDuration$1a9ae18f() {
        this.mTransition.setDuration(115L);
        return this;
    }

    @Override // android.support.transition.TransitionImpl
    public final TransitionImpl setInterpolator(TimeInterpolator interpolator) {
        this.mTransition.setInterpolator(interpolator);
        return this;
    }

    public String toString() {
        return this.mTransition.toString();
    }

    /* loaded from: classes.dex */
    private static class TransitionWrapper extends android.transition.Transition {
        private TransitionInterface mTransition;

        public TransitionWrapper(TransitionInterface transition) {
            this.mTransition = transition;
        }

        @Override // android.transition.Transition
        public final void captureStartValues(android.transition.TransitionValues transitionValues) {
            TransitionInterface transitionInterface = this.mTransition;
            TransitionValues transitionValues2 = new TransitionValues();
            TransitionKitKat.copyValues(transitionValues, transitionValues2);
            transitionInterface.captureStartValues(transitionValues2);
            TransitionKitKat.copyValues(transitionValues2, transitionValues);
        }

        @Override // android.transition.Transition
        public final void captureEndValues(android.transition.TransitionValues transitionValues) {
            TransitionInterface transitionInterface = this.mTransition;
            TransitionValues transitionValues2 = new TransitionValues();
            TransitionKitKat.copyValues(transitionValues, transitionValues2);
            transitionInterface.captureEndValues(transitionValues2);
            TransitionKitKat.copyValues(transitionValues2, transitionValues);
        }

        @Override // android.transition.Transition
        public final Animator createAnimator(ViewGroup sceneRoot, android.transition.TransitionValues startValues, android.transition.TransitionValues endValues) {
            return this.mTransition.createAnimator(sceneRoot, TransitionKitKat.convertToSupport(startValues), TransitionKitKat.convertToSupport(endValues));
        }
    }
}
