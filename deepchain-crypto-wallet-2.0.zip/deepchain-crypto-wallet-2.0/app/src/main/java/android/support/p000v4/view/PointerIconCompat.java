package android.support.p000v4.view;

import android.content.Context;
import android.support.p000v4.p001os.BuildCompat;
import android.view.PointerIcon;

/* renamed from: android.support.v4.view.PointerIconCompat */
/* loaded from: classes.dex */
public final class PointerIconCompat {
    static final PointerIconCompatImpl IMPL;
    Object mPointerIcon;

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: android.support.v4.view.PointerIconCompat$PointerIconCompatImpl */
    /* loaded from: classes.dex */
    public interface PointerIconCompatImpl {
        Object getSystemIcon$9f781c2(Context context);
    }

    private PointerIconCompat(Object pointerIcon) {
        this.mPointerIcon = pointerIcon;
    }

    /* renamed from: android.support.v4.view.PointerIconCompat$BasePointerIconCompatImpl */
    /* loaded from: classes.dex */
    static class BasePointerIconCompatImpl implements PointerIconCompatImpl {
        BasePointerIconCompatImpl() {
        }

        @Override // android.support.p000v4.view.PointerIconCompat.PointerIconCompatImpl
        public Object getSystemIcon$9f781c2(Context context) {
            return null;
        }
    }

    /* renamed from: android.support.v4.view.PointerIconCompat$Api24PointerIconCompatImpl */
    /* loaded from: classes.dex */
    static class Api24PointerIconCompatImpl extends BasePointerIconCompatImpl {
        Api24PointerIconCompatImpl() {
        }

        @Override // android.support.p000v4.view.PointerIconCompat.BasePointerIconCompatImpl, android.support.p000v4.view.PointerIconCompat.PointerIconCompatImpl
        public final Object getSystemIcon$9f781c2(Context context) {
            return PointerIcon.getSystemIcon(context, 1002);
        }
    }

    static {
        if (BuildCompat.isAtLeastN()) {
            IMPL = new Api24PointerIconCompatImpl();
        } else {
            IMPL = new BasePointerIconCompatImpl();
        }
    }

    public static PointerIconCompat getSystemIcon$45510cc2(Context context) {
        return new PointerIconCompat(IMPL.getSystemIcon$9f781c2(context));
    }
}
