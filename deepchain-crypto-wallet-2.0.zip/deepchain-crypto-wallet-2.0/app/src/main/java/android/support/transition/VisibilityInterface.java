package android.support.transition;

/* loaded from: classes.dex */
interface VisibilityInterface extends TransitionInterface {
}
