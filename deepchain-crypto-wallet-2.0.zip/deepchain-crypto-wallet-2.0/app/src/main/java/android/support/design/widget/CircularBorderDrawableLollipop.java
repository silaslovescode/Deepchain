package android.support.design.widget;

import android.annotation.TargetApi;
import android.graphics.Outline;

@TargetApi(21)
/* loaded from: classes.dex */
final class CircularBorderDrawableLollipop extends CircularBorderDrawable {
    @Override // android.graphics.drawable.Drawable
    public final void getOutline(Outline outline) {
        copyBounds(this.mRect);
        outline.setOval(this.mRect);
    }
}
