package android.support.p000v4.view.accessibility;

import android.os.Build;
import android.os.Bundle;
import android.support.p000v4.view.accessibility.AccessibilityNodeProviderCompatJellyBean;
import android.support.p000v4.view.accessibility.AccessibilityNodeProviderCompatKitKat;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import java.util.List;

/* renamed from: android.support.v4.view.accessibility.AccessibilityNodeProviderCompat */
/* loaded from: classes.dex */
public final class AccessibilityNodeProviderCompat {
    private static final AccessibilityNodeProviderImpl IMPL;
    public final Object mProvider;

    /* renamed from: android.support.v4.view.accessibility.AccessibilityNodeProviderCompat$AccessibilityNodeProviderImpl */
    /* loaded from: classes.dex */
    interface AccessibilityNodeProviderImpl {
        Object newAccessibilityNodeProviderBridge(AccessibilityNodeProviderCompat accessibilityNodeProviderCompat);
    }

    /* renamed from: android.support.v4.view.accessibility.AccessibilityNodeProviderCompat$AccessibilityNodeProviderStubImpl */
    /* loaded from: classes.dex */
    static class AccessibilityNodeProviderStubImpl implements AccessibilityNodeProviderImpl {
        AccessibilityNodeProviderStubImpl() {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeProviderCompat.AccessibilityNodeProviderImpl
        public Object newAccessibilityNodeProviderBridge(AccessibilityNodeProviderCompat compat) {
            return null;
        }
    }

    /* renamed from: android.support.v4.view.accessibility.AccessibilityNodeProviderCompat$AccessibilityNodeProviderJellyBeanImpl */
    /* loaded from: classes.dex */
    private static class AccessibilityNodeProviderJellyBeanImpl extends AccessibilityNodeProviderStubImpl {
        AccessibilityNodeProviderJellyBeanImpl() {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeProviderCompat.AccessibilityNodeProviderStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeProviderCompat.AccessibilityNodeProviderImpl
        public final Object newAccessibilityNodeProviderBridge(final AccessibilityNodeProviderCompat compat) {
            final AccessibilityNodeProviderCompatJellyBean.AccessibilityNodeInfoBridge accessibilityNodeInfoBridge = new AccessibilityNodeProviderCompatJellyBean.AccessibilityNodeInfoBridge() { // from class: android.support.v4.view.accessibility.AccessibilityNodeProviderCompat.AccessibilityNodeProviderJellyBeanImpl.1
                @Override // android.support.p000v4.view.accessibility.AccessibilityNodeProviderCompatJellyBean.AccessibilityNodeInfoBridge
                public final boolean performAction$5985f823() {
                    return AccessibilityNodeProviderCompat.performAction$5985f823();
                }

                @Override // android.support.p000v4.view.accessibility.AccessibilityNodeProviderCompatJellyBean.AccessibilityNodeInfoBridge
                public final List<Object> findAccessibilityNodeInfosByText$2393931d() {
                    AccessibilityNodeProviderCompat.findAccessibilityNodeInfosByText$2393931d();
                    return null;
                }

                @Override // android.support.p000v4.view.accessibility.AccessibilityNodeProviderCompatJellyBean.AccessibilityNodeInfoBridge
                public final Object createAccessibilityNodeInfo$54cf32c4() {
                    AccessibilityNodeProviderCompat.createAccessibilityNodeInfo$f3a5639();
                    return null;
                }
            };
            return new AccessibilityNodeProvider() { // from class: android.support.v4.view.accessibility.AccessibilityNodeProviderCompatJellyBean.1
                @Override // android.view.accessibility.AccessibilityNodeProvider
                public final AccessibilityNodeInfo createAccessibilityNodeInfo(int virtualViewId) {
                    accessibilityNodeInfoBridge.createAccessibilityNodeInfo$54cf32c4();
                    return null;
                }

                @Override // android.view.accessibility.AccessibilityNodeProvider
                public final List<AccessibilityNodeInfo> findAccessibilityNodeInfosByText(String text, int virtualViewId) {
                    return accessibilityNodeInfoBridge.findAccessibilityNodeInfosByText$2393931d();
                }

                @Override // android.view.accessibility.AccessibilityNodeProvider
                public final boolean performAction(int virtualViewId, int action, Bundle arguments) {
                    return accessibilityNodeInfoBridge.performAction$5985f823();
                }
            };
        }
    }

    /* renamed from: android.support.v4.view.accessibility.AccessibilityNodeProviderCompat$AccessibilityNodeProviderKitKatImpl */
    /* loaded from: classes.dex */
    private static class AccessibilityNodeProviderKitKatImpl extends AccessibilityNodeProviderStubImpl {
        AccessibilityNodeProviderKitKatImpl() {
        }

        @Override // android.support.p000v4.view.accessibility.AccessibilityNodeProviderCompat.AccessibilityNodeProviderStubImpl, android.support.p000v4.view.accessibility.AccessibilityNodeProviderCompat.AccessibilityNodeProviderImpl
        public final Object newAccessibilityNodeProviderBridge(final AccessibilityNodeProviderCompat compat) {
            final AccessibilityNodeProviderCompatKitKat.AccessibilityNodeInfoBridge accessibilityNodeInfoBridge = new AccessibilityNodeProviderCompatKitKat.AccessibilityNodeInfoBridge() { // from class: android.support.v4.view.accessibility.AccessibilityNodeProviderCompat.AccessibilityNodeProviderKitKatImpl.1
                @Override // android.support.p000v4.view.accessibility.AccessibilityNodeProviderCompatKitKat.AccessibilityNodeInfoBridge
                public final boolean performAction$5985f823() {
                    return AccessibilityNodeProviderCompat.performAction$5985f823();
                }

                @Override // android.support.p000v4.view.accessibility.AccessibilityNodeProviderCompatKitKat.AccessibilityNodeInfoBridge
                public final List<Object> findAccessibilityNodeInfosByText$2393931d() {
                    AccessibilityNodeProviderCompat.findAccessibilityNodeInfosByText$2393931d();
                    return null;
                }

                @Override // android.support.p000v4.view.accessibility.AccessibilityNodeProviderCompatKitKat.AccessibilityNodeInfoBridge
                public final Object createAccessibilityNodeInfo$54cf32c4() {
                    AccessibilityNodeProviderCompat.createAccessibilityNodeInfo$f3a5639();
                    return null;
                }

                @Override // android.support.p000v4.view.accessibility.AccessibilityNodeProviderCompatKitKat.AccessibilityNodeInfoBridge
                public final Object findFocus$54cf32c4() {
                    AccessibilityNodeProviderCompat.findFocus$f3a5639();
                    return null;
                }
            };
            return new AccessibilityNodeProvider() { // from class: android.support.v4.view.accessibility.AccessibilityNodeProviderCompatKitKat.1
                @Override // android.view.accessibility.AccessibilityNodeProvider
                public final AccessibilityNodeInfo createAccessibilityNodeInfo(int virtualViewId) {
                    accessibilityNodeInfoBridge.createAccessibilityNodeInfo$54cf32c4();
                    return null;
                }

                @Override // android.view.accessibility.AccessibilityNodeProvider
                public final List<AccessibilityNodeInfo> findAccessibilityNodeInfosByText(String text, int virtualViewId) {
                    return accessibilityNodeInfoBridge.findAccessibilityNodeInfosByText$2393931d();
                }

                @Override // android.view.accessibility.AccessibilityNodeProvider
                public final boolean performAction(int virtualViewId, int action, Bundle arguments) {
                    return accessibilityNodeInfoBridge.performAction$5985f823();
                }

                @Override // android.view.accessibility.AccessibilityNodeProvider
                public final AccessibilityNodeInfo findFocus(int focus) {
                    accessibilityNodeInfoBridge.findFocus$54cf32c4();
                    return null;
                }
            };
        }
    }

    static {
        if (Build.VERSION.SDK_INT >= 19) {
            IMPL = new AccessibilityNodeProviderKitKatImpl();
        } else if (Build.VERSION.SDK_INT >= 16) {
            IMPL = new AccessibilityNodeProviderJellyBeanImpl();
        } else {
            IMPL = new AccessibilityNodeProviderStubImpl();
        }
    }

    public AccessibilityNodeProviderCompat() {
        this.mProvider = IMPL.newAccessibilityNodeProviderBridge(this);
    }

    public AccessibilityNodeProviderCompat(Object provider) {
        this.mProvider = provider;
    }

    public static AccessibilityNodeInfoCompat createAccessibilityNodeInfo$f3a5639() {
        return null;
    }

    public static boolean performAction$5985f823() {
        return false;
    }

    public static List<AccessibilityNodeInfoCompat> findAccessibilityNodeInfosByText$2393931d() {
        return null;
    }

    public static AccessibilityNodeInfoCompat findFocus$f3a5639() {
        return null;
    }
}
