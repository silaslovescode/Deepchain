package android.support.p000v4.widget;

import android.graphics.drawable.Drawable;
import android.os.Build;
import android.widget.TextView;

/* renamed from: android.support.v4.widget.TextViewCompat */
/* loaded from: classes.dex */
public final class TextViewCompat {
    static final TextViewCompatImpl IMPL;

    /* renamed from: android.support.v4.widget.TextViewCompat$TextViewCompatImpl */
    /* loaded from: classes.dex */
    interface TextViewCompatImpl {
        Drawable[] getCompoundDrawablesRelative(TextView textView);

        int getMaxLines(TextView textView);

        void setCompoundDrawablesRelative(TextView textView, Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4);

        void setTextAppearance(TextView textView, int i);
    }

    /* renamed from: android.support.v4.widget.TextViewCompat$BaseTextViewCompatImpl */
    /* loaded from: classes.dex */
    static class BaseTextViewCompatImpl implements TextViewCompatImpl {
        BaseTextViewCompatImpl() {
        }

        @Override // android.support.p000v4.widget.TextViewCompat.TextViewCompatImpl
        public void setCompoundDrawablesRelative(TextView textView, Drawable start, Drawable top, Drawable end, Drawable bottom) {
            textView.setCompoundDrawables(start, top, end, bottom);
        }

        @Override // android.support.p000v4.widget.TextViewCompat.TextViewCompatImpl
        public int getMaxLines(TextView textView) {
            if (!TextViewCompatGingerbread.sMaxModeFieldFetched) {
                TextViewCompatGingerbread.sMaxModeField = TextViewCompatGingerbread.retrieveField("mMaxMode");
                TextViewCompatGingerbread.sMaxModeFieldFetched = true;
            }
            if (TextViewCompatGingerbread.sMaxModeField != null && TextViewCompatGingerbread.retrieveIntFromField(TextViewCompatGingerbread.sMaxModeField, textView) == 1) {
                if (!TextViewCompatGingerbread.sMaximumFieldFetched) {
                    TextViewCompatGingerbread.sMaximumField = TextViewCompatGingerbread.retrieveField("mMaximum");
                    TextViewCompatGingerbread.sMaximumFieldFetched = true;
                }
                if (TextViewCompatGingerbread.sMaximumField != null) {
                    return TextViewCompatGingerbread.retrieveIntFromField(TextViewCompatGingerbread.sMaximumField, textView);
                }
            }
            return -1;
        }

        @Override // android.support.p000v4.widget.TextViewCompat.TextViewCompatImpl
        public void setTextAppearance(TextView textView, int resId) {
            textView.setTextAppearance(textView.getContext(), resId);
        }

        @Override // android.support.p000v4.widget.TextViewCompat.TextViewCompatImpl
        public Drawable[] getCompoundDrawablesRelative(TextView textView) {
            return textView.getCompoundDrawables();
        }
    }

    /* renamed from: android.support.v4.widget.TextViewCompat$JbTextViewCompatImpl */
    /* loaded from: classes.dex */
    static class JbTextViewCompatImpl extends BaseTextViewCompatImpl {
        JbTextViewCompatImpl() {
        }

        @Override // android.support.p000v4.widget.TextViewCompat.BaseTextViewCompatImpl, android.support.p000v4.widget.TextViewCompat.TextViewCompatImpl
        public final int getMaxLines(TextView textView) {
            return textView.getMaxLines();
        }
    }

    /* renamed from: android.support.v4.widget.TextViewCompat$JbMr1TextViewCompatImpl */
    /* loaded from: classes.dex */
    static class JbMr1TextViewCompatImpl extends JbTextViewCompatImpl {
        JbMr1TextViewCompatImpl() {
        }

        @Override // android.support.p000v4.widget.TextViewCompat.BaseTextViewCompatImpl, android.support.p000v4.widget.TextViewCompat.TextViewCompatImpl
        public void setCompoundDrawablesRelative(TextView textView, Drawable start, Drawable top, Drawable end, Drawable bottom) {
            boolean z = textView.getLayoutDirection() == 1;
            Drawable drawable = z ? end : start;
            if (!z) {
                start = end;
            }
            textView.setCompoundDrawables(drawable, top, start, bottom);
        }

        @Override // android.support.p000v4.widget.TextViewCompat.BaseTextViewCompatImpl, android.support.p000v4.widget.TextViewCompat.TextViewCompatImpl
        public Drawable[] getCompoundDrawablesRelative(TextView textView) {
            boolean z = true;
            if (textView.getLayoutDirection() != 1) {
                z = false;
            }
            Drawable[] compoundDrawables = textView.getCompoundDrawables();
            if (z) {
                Drawable drawable = compoundDrawables[2];
                Drawable drawable2 = compoundDrawables[0];
                compoundDrawables[0] = drawable;
                compoundDrawables[2] = drawable2;
            }
            return compoundDrawables;
        }
    }

    /* renamed from: android.support.v4.widget.TextViewCompat$JbMr2TextViewCompatImpl */
    /* loaded from: classes.dex */
    static class JbMr2TextViewCompatImpl extends JbMr1TextViewCompatImpl {
        JbMr2TextViewCompatImpl() {
        }

        @Override // android.support.p000v4.widget.TextViewCompat.JbMr1TextViewCompatImpl, android.support.p000v4.widget.TextViewCompat.BaseTextViewCompatImpl, android.support.p000v4.widget.TextViewCompat.TextViewCompatImpl
        public final void setCompoundDrawablesRelative(TextView textView, Drawable start, Drawable top, Drawable end, Drawable bottom) {
            textView.setCompoundDrawablesRelative(start, top, end, bottom);
        }

        @Override // android.support.p000v4.widget.TextViewCompat.JbMr1TextViewCompatImpl, android.support.p000v4.widget.TextViewCompat.BaseTextViewCompatImpl, android.support.p000v4.widget.TextViewCompat.TextViewCompatImpl
        public final Drawable[] getCompoundDrawablesRelative(TextView textView) {
            return textView.getCompoundDrawablesRelative();
        }
    }

    /* renamed from: android.support.v4.widget.TextViewCompat$Api23TextViewCompatImpl */
    /* loaded from: classes.dex */
    static class Api23TextViewCompatImpl extends JbMr2TextViewCompatImpl {
        Api23TextViewCompatImpl() {
        }

        @Override // android.support.p000v4.widget.TextViewCompat.BaseTextViewCompatImpl, android.support.p000v4.widget.TextViewCompat.TextViewCompatImpl
        public final void setTextAppearance(TextView textView, int resId) {
            textView.setTextAppearance(resId);
        }
    }

    static {
        int version = Build.VERSION.SDK_INT;
        if (version >= 23) {
            IMPL = new Api23TextViewCompatImpl();
        } else if (version >= 18) {
            IMPL = new JbMr2TextViewCompatImpl();
        } else if (version >= 17) {
            IMPL = new JbMr1TextViewCompatImpl();
        } else if (version >= 16) {
            IMPL = new JbTextViewCompatImpl();
        } else {
            IMPL = new BaseTextViewCompatImpl();
        }
    }

    public static void setCompoundDrawablesRelative(TextView textView, Drawable start, Drawable top, Drawable end, Drawable bottom) {
        IMPL.setCompoundDrawablesRelative(textView, start, top, end, bottom);
    }

    public static int getMaxLines(TextView textView) {
        return IMPL.getMaxLines(textView);
    }

    public static void setTextAppearance(TextView textView, int resId) {
        IMPL.setTextAppearance(textView, resId);
    }

    public static Drawable[] getCompoundDrawablesRelative(TextView textView) {
        return IMPL.getCompoundDrawablesRelative(textView);
    }
}
