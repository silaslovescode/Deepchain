package android.support.p000v4.view;

import android.annotation.TargetApi;

@TargetApi(14)
/* renamed from: android.support.v4.view.ViewPropertyAnimatorCompatICS */
/* loaded from: classes.dex */
final class ViewPropertyAnimatorCompatICS {
}
