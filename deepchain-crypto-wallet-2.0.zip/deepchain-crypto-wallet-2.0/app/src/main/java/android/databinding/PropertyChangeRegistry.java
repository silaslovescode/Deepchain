package android.databinding;

import android.databinding.CallbackRegistry;
import android.databinding.Observable;

/* loaded from: classes.dex */
public final class PropertyChangeRegistry extends CallbackRegistry<Observable.OnPropertyChangedCallback, Observable, Void> {
    private static final CallbackRegistry.NotifierCallback<Observable.OnPropertyChangedCallback, Observable, Void> NOTIFIER_CALLBACK = new CallbackRegistry.NotifierCallback<Observable.OnPropertyChangedCallback, Observable, Void>() { // from class: android.databinding.PropertyChangeRegistry.1
        @Override // android.databinding.CallbackRegistry.NotifierCallback
        public final /* bridge */ /* synthetic */ void onNotifyCallback$3215a152(Observable.OnPropertyChangedCallback onPropertyChangedCallback, Observable observable, int i) {
            onPropertyChangedCallback.onPropertyChanged(observable, i);
        }
    };

    public PropertyChangeRegistry() {
        super(NOTIFIER_CALLBACK);
    }
}
