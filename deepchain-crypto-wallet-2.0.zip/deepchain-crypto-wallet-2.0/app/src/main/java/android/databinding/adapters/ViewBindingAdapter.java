package android.databinding.adapters;

import android.view.View;

/* loaded from: classes.dex */
public final class ViewBindingAdapter {
    public static int FADING_EDGE_NONE = 0;
    public static int FADING_EDGE_HORIZONTAL = 1;
    public static int FADING_EDGE_VERTICAL = 2;

    public static void setOnClick(View view, View.OnClickListener clickListener, boolean clickable) {
        view.setOnClickListener(clickListener);
        view.setClickable(clickable);
    }
}
